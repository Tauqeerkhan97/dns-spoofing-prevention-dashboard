import React, { useState, useEffect, useRef } from 'react';
import { DNSPacket, RuleWeights, FilterStage, SystemLogEntry } from '../types';
import { 
  generateCleanPacket, 
  generateSpoofedPacket 
} from '../utils/dns_simulator';
import { 
  Play, Square, Cpu, ShieldAlert, Activity, CheckCircle, 
  AlertTriangle, Network, ArrowRight, Shield, ListCollapse,
  RefreshCw, Terminal, Eye, Sliders
} from 'lucide-react';

interface LiveMonitorProps {
  packets: DNSPacket[];
  onAddPacket: (pkt: DNSPacket) => void;
  onClearPackets: () => void;
  weights: RuleWeights;
  blacklist: string[];
  onAddSystemLog: (comp: 'Daemon' | 'GUI' | 'Updater' | 'Mitigator', lvl: 'info' | 'warning' | 'error' | 'success', msg: string) => void;
  mitigationState: { dnsCacheFlushed: boolean; dohForced: boolean; firewallRulesCount: number; hostsFileSecure: boolean };
}

export default function LiveMonitor({
  packets,
  onAddPacket,
  onClearPackets,
  weights,
  blacklist,
  onAddSystemLog,
  mitigationState
}: LiveMonitorProps) {
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [activeNic, setActiveNic] = useState<string>('WLAN0 (Active Wireless)');
  const [selectedPacket, setSelectedPacket] = useState<DNSPacket | null>(null);
  const [simulationRate, setSimulationRate] = useState<number>(1.5); // packets per second when auto-running
  const [inspectingStage, setInspectingStage] = useState<string | null>(null);

  const autoQueryTimer = useRef<NodeJS.Timeout | null>(null);

  // Filter Stages model matching Assignment Section 4 + 3.1
  const filterStages: FilterStage[] = [
    { id: 'pcap', name: 'Raw Capture', role: 'Scapy Packet Bind', icon: 'Network', description: 'Binds to network interface, captures raw socket streams at line-rate.', status: 'idle', count: packets.length },
    { id: 'parser', name: 'DNS Parser', role: 'Header Decoder', icon: 'Cpu', description: 'Decodes 16-bit transaction IDs, QR flags, TTL values, and RR payload maps.', status: 'idle', count: packets.length },
    { id: 'blacklist', name: 'Feed Check', role: 'Local IP/Domain list', icon: 'ListCollapse', description: 'Cross-checks queries against active malware risk feeds in SQLite.', status: 'idle', count: packets.filter(p => p.riskScore >= 45).length },
    { id: 'dnssec', name: 'DNSSEC Validation', role: 'Crypto Verification', icon: 'Shield', description: 'Performs offline signature evaluation on standard trust-anchor signatures.', status: 'idle', count: packets.filter(p => p.dnssecValidated).length },
    { id: 'doh', name: 'DoH Cross-Check', role: 'Multipath Consensus', icon: 'RefreshCw', description: 'Queries trusted DoH servers to verify local resolver answers.', status: 'idle', count: packets.filter(p => p.isSpoofedSimulation === false).length },
    { id: 'dispatcher', name: 'Alert Handler', role: 'Active Defense Hub', icon: 'ShieldAlert', description: 'Triggers local alerts and coordinates mitigations for high-threat packets.', status: 'idle', count: packets.filter(p => p.status !== 'clean').length }
  ];

  // Auto-generator effect
  useEffect(() => {
    if (isRunning) {
      const intervalMs = (1 / simulationRate) * 1000;
      autoQueryTimer.current = setInterval(() => {
        // 90% chance normal clean DNS packet, 10% chance suspicious
        if (Math.random() > 0.15) {
          const pkt = generateCleanPacket(blacklist);
          onAddPacket(pkt);
        } else {
          const types: ('mismatch' | 'ttl_hijack' | 'blacklist_threat')[] = ['mismatch', 'ttl_hijack', 'blacklist_threat'];
          const randomType = types[Math.floor(Math.random() * types.length)];
          const pkt = generateSpoofedPacket(randomType, blacklist);
          onAddPacket(pkt);
          
          if (pkt.status === 'spoofed') {
            onAddSystemLog('Daemon', 'error', `SPOOF ALERT DETECTED for domain ${pkt.domain}: Risk score ${pkt.riskScore}%!`);
          } else {
            onAddSystemLog('Daemon', 'warning', `Anomalous DNS packet for ${pkt.domain}: Risk score ${pkt.riskScore}%!`);
          }
        }
      }, intervalMs);
    } else {
      if (autoQueryTimer.current) clearInterval(autoQueryTimer.current);
    }

    return () => {
      if (autoQueryTimer.current) clearInterval(autoQueryTimer.current);
    };
  }, [isRunning, simulationRate, blacklist]);

  // Handle single manual clean query injection
  const injectCleanQuery = () => {
    const pkt = generateCleanPacket(blacklist);
    onAddPacket(pkt);
    onAddSystemLog('Daemon', 'info', `Injected targeted query evaluation for ${pkt.domain}.`);
  };

  // Handle manual attack injection
  const injectAttackQuery = (type: 'tx_hijack' | 'mismatch' | 'ttl_hijack') => {
    const pkt = generateSpoofedPacket(type, blacklist);
    onAddPacket(pkt);
    onAddSystemLog('Daemon', 'error', `INTRUSION ALERT: Injected simulated attack vector [${type.toUpperCase()}] targeting ${pkt.domain}!`);
  };

  // Stats calculators
  const stats = {
    total: packets.length,
    clean: packets.filter(p => p.status === 'clean').length,
    suspicious: packets.filter(p => p.status === 'suspicious').length,
    spoofed: packets.filter(p => p.status === 'spoofed').length,
    avgLatency: packets.length > 0 ? Math.round(packets.reduce((acc, p) => acc + p.latencyMs, 0) / packets.length) : 0,
    sizeProcessed: packets.reduce((acc, p) => acc + p.sizeBytes, 0)
  };

  return (
    <div className="space-y-6">
      
      {/* Simulation Controls Strip */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
        
        <div className="md:col-span-4 flex items-center justify-between md:justify-start gap-4">
          <div className="flex items-center gap-2">
            <span className={`h-2.5 w-2.5 rounded-full ${isRunning ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
            <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">Daemon State:</h3>
          </div>
          <div className="flex gap-2">
            {isRunning ? (
              <button 
                onClick={() => {
                  setIsRunning(false);
                  onAddSystemLog('GUI', 'warning', 'SAD daemon process paused by user control.');
                }}
                className="flex items-center gap-1.5 bg-rose-950/40 border border-rose-800/50 hover:bg-rose-900/40 text-rose-300 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer"
              >
                <Square size={12} /> Pause Capture
              </button>
            ) : (
              <button 
                onClick={() => {
                  setIsRunning(true);
                  onAddSystemLog('GUI', 'success', 'SAD daemon process started. Listening on raw interfaces.');
                }}
                className="flex items-center gap-1.5 bg-emerald-950/45 border border-emerald-800/50 hover:bg-emerald-900/40 text-emerald-300 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer"
              >
                <Play size={12} /> Resume Sniffing
              </button>
            )}
            <button 
              onClick={onClearPackets}
              className="bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-300 px-2.5 py-1.5 rounded-lg text-xs font-semibold cursor-pointer"
            >
              Clear Log
            </button>
          </div>
        </div>

        {/* Bind NIC Selector */}
        <div className="md:col-span-5 flex items-center gap-2">
          <span className="text-slate-400 font-mono text-[10px] uppercase truncate shrink-0">NIC Interface:</span>
          <select 
            value={activeNic}
            onChange={(e) => {
              setActiveNic(e.target.value);
              onAddSystemLog('Daemon', 'info', `Bound raw capture sockets to ${e.target.value}`);
            }}
            className="w-full bg-slate-900 text-slate-200 border border-slate-800 rounded-lg py-1 px-2.5 text-xs font-mono outline-none focus:border-cyan-800/60"
          >
            <option>WLAN0 (Active Wireless)</option>
            <option>ETH0 (Pcap Host Interface)</option>
            <option>LO (Local DNS Loopback)</option>
            <option>NPcap Bridge Mode (Promiscuous)</option>
          </select>
        </div>

        {/* Capture speed controller */}
        <div className="md:col-span-3 flex items-center gap-2">
          <span className="text-slate-400 font-mono text-[10px] uppercase shrink-0">Rate:</span>
          <input 
            type="range" 
            min="0.2" 
            max="4" 
            step="0.2"
            value={simulationRate} 
            onChange={(e) => setSimulationRate(Number(e.target.value))}
            className="w-full accent-cyan-500 bg-slate-900 h-1.5 rounded"
          />
          <span className="text-slate-200 text-xs font-mono shrink-0 w-8 text-right">{simulationRate} Q/s</span>
        </div>

      </div>

      {/* Numerical Stats Displays */}
      <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
        
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
          <p className="text-[10px] font-mono uppercase tracking-widest text-slate-500">Inspected</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-slate-100 font-mono">{stats.total}</span>
            <span className="text-[10px] text-slate-400 font-mono">pkts</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 truncate">Speed: {simulationRate} packets/sec</p>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
          <p className="text-[10px] font-mono uppercase tracking-widest text-[#10b981]">Clean status</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-[#10b981] font-mono">{stats.clean}</span>
            <span className="text-[10px] text-emerald-400 font-mono">
              {stats.total > 0 ? Math.round((stats.clean / stats.total) * 100) : 0}%
            </span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 truncate">Fully validated frames</p>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
          <p className="text-[10px] font-mono uppercase tracking-widest text-amber-400">Suspicious</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-amber-400 font-mono">{stats.suspicious}</span>
            <span className="text-[10px] text-amber-500 font-mono">
              {stats.total > 0 ? Math.round((stats.suspicious / stats.total) * 100) : 0}%
            </span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 truncate">Minor TTL or ID anomalies</p>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 text-rose-400">
          <p className="text-[10px] font-mono uppercase tracking-widest text-red-500">Spoof alerts</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-red-500 font-mono">{stats.spoofed}</span>
            <span className="text-[10px] text-rose-500 font-mono">
              {stats.total > 0 ? Math.round((stats.spoofed / stats.total) * 100) : 0}%
            </span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 truncate">Mitigations targeted</p>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
          <p className="text-[10px] font-mono uppercase tracking-widest text-cyan-400">Avg Latency</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-cyan-400 font-mono">{stats.avgLatency}</span>
            <span className="text-[10px] text-cyan-500 font-mono">ms</span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 truncate">DoH vs Gateway benchmark</p>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
          <p className="text-[10px] font-mono uppercase tracking-widest text-slate-550">Traffic Volume</p>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-slate-200 font-mono">
              {stats.sizeProcessed > 1048576 
                ? (stats.sizeProcessed / 1048576).toFixed(1) 
                : (stats.sizeProcessed / 1024).toFixed(1)}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              {stats.sizeProcessed > 1048576 ? 'MB' : 'KB'}
            </span>
          </div>
          <p className="text-[10px] text-slate-400 mt-2 truncate">Decoded payload bytes</p>
        </div>

      </div>

      {/* Visual Pipeline (Section 4 Component View & Section 2 Pipe-and-Filter Style) */}
      <div className="bg-slate-950 rounded-xl border border-slate-800/80 p-5">
        <div className="flex items-center justify-between mb-4 border-b border-slate-900 pb-3">
          <div className="flex items-center gap-2">
            <Activity className="text-cyan-400" size={16} />
            <h3 className="font-bold text-slate-100 text-sm tracking-wider uppercase">
              Section 4: DNSGuard Pipeline Filters
            </h3>
          </div>
          <span className="text-[10px] font-mono text-cyan-500 tracking-wider">
            Pipe-and-Filter Stream (ADR-5)
          </span>
        </div>

        {/* Horizontal flow line representation */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-3 relative mt-2">
          {filterStages.map((stage, idx) => {
            const isStageProcessing = isRunning && (stats.total > 0) && (idx === Math.floor(Date.now() / 800) % 6);
            return (
              <div 
                key={stage.id}
                onClick={() => setInspectingStage(stage.id)}
                className={`relative p-3.5 rounded-xl border transition duration-150 select-none cursor-pointer flex flex-col justify-between ${
                  inspectingStage === stage.id
                    ? 'bg-cyan-950/40 border-cyan-500 text-slate-200 shadow-md shadow-cyan-950/25'
                    : isStageProcessing
                    ? 'bg-slate-900 border-indigo-700/60 text-slate-300'
                    : 'bg-slate-900/40 border-slate-800 hover:border-slate-700 text-slate-400'
                }`}
              >
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-100">
                      {stage.name}
                    </span>
                    <span className={`h-1.5 w-1.5 rounded-full ${isStageProcessing ? 'bg-indigo-400 animate-ping' : 'bg-slate-700'}`} />
                  </div>
                  <p className="text-[10px] text-cyan-400/80 font-mono truncate">{stage.role}</p>
                </div>
                <div className="mt-3 flex items-baseline justify-between border-t border-slate-800/60 pt-2 font-mono text-xs">
                  <span className="text-[10px] text-slate-500 uppercase">Load:</span>
                  <span className="text-slate-200 font-bold">{stage.count}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Filter Stage details drawer */}
        {inspectingStage && (
          <div className="bg-slate-900 rounded-xl p-4 border border-slate-800/80 mt-4 text-xs">
            <div className="flex justify-between items-center mb-1">
              <h4 className="font-bold text-cyan-400 flex items-center gap-1.5 uppercase font-mono tracking-wide text-xs">
                <span>Filter Node:</span>
                <span>{filterStages.find(s => s.id === inspectingStage)?.name}</span>
                <span className="text-slate-500">({filterStages.find(s => s.id === inspectingStage)?.role})</span>
              </h4>
              <button 
                onClick={() => setInspectingStage(null)} 
                className="text-slate-500 hover:text-slate-200 text-[10px] font-bold uppercase cursor-pointer"
              >
                Close Info
              </button>
            </div>
            <p className="text-slate-300 mb-2 leading-relaxed">
              {filterStages.find(s => s.id === inspectingStage)?.description}
            </p>
            <div className="text-[10px] text-slate-500 border-t border-slate-800/60 pt-2 flex flex-col sm:flex-row sm:gap-4 font-mono">
              <span>Implementation Class: <span className="text-slate-300">`dnsguard.domain.detection.IFilter`</span></span>
              <span>Input Node: <span className="text-slate-300">BoundedQueueBuffer[max=10K]</span></span>
              <span>Concurrency Scheme: <span className="text-slate-300">Asymmetric worker thread-pools</span></span>
            </div>
          </div>
        )}

      </div>

      {/* Manual Attack Generation & Action Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Core Live Packet Stream logs */}
        <div className="lg:col-span-8 bg-slate-950 rounded-xl border border-slate-800/80 p-5 flex flex-col justify-between h-[390px]">
          
          <div className="flex items-center justify-between border-b border-slate-900 pb-2 mb-3">
            <div className="flex items-center gap-2">
              <Terminal className="text-indigo-400 animate-pulse" size={15} />
              <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">Live Raw Packet capture logs</h3>
            </div>
            <span className="text-[10px] font-mono text-slate-500 truncate uppercase max-w-[140px] sm:max-w-none">
              socket buffer • sniffing WLAN0
            </span>
          </div>

          <div className="overflow-y-auto flex-1 h-full pr-1 font-mono text-xs space-y-1.5 scrollbar-thin">
            {packets.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-600 space-y-2 py-10">
                <Network size={28} className="text-slate-700 animate-pulse" />
                <p className="text-center text-[11px] leading-relaxed">
                  Socket binder listening... Waiting for incoming queries inside live buffers.<br />
                  <span className="text-cyan-400 font-bold hover:underline cursor-pointer" onClick={injectCleanQuery}>Inject test packet</span> or start simulator above.
                </p>
              </div>
            ) : (
              [...packets].reverse().slice(0, 40).map((pkt) => {
                let badgeColor = 'bg-emerald-950/40 border-emerald-800/50 text-[#10b981]';
                if (pkt.status === 'suspicious') badgeColor = 'bg-yellow-950/40 border-yellow-800/50 text-yellow-300';
                if (pkt.status === 'spoofed') badgeColor = 'bg-rose-950/40 border-rose-800/50 text-rose-400';

                return (
                  <div 
                    key={pkt.id} 
                    onClick={() => setSelectedPacket(pkt)}
                    className={`p-2.5 rounded border flex flex-col sm:flex-row items-start sm:items-center justify-between text-[11px] transition select-none cursor-pointer ${
                      selectedPacket?.id === pkt.id 
                        ? 'bg-slate-900/80 border-cyan-700 text-slate-100' 
                        : 'bg-slate-950 border-slate-900/80 hover:bg-slate-900/30 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-3 w-full sm:w-auto truncate">
                      <span className="text-[10px] text-slate-500 font-mono shrink-0">{pkt.timestamp}</span>
                      <span className="text-cyan-400 font-bold shrink-0">TX {pkt.transactionId}</span>
                      <span className="bg-slate-900 px-1 text-slate-400 rounded shrink-0 text-[10px]">{pkt.queryType}</span>
                      <span className="truncate text-slate-200 font-semibold">{pkt.domain}</span>
                    </div>

                    <div className="flex items-center gap-2 mt-1.5 sm:mt-0 ml-7 sm:ml-0 self-end sm:self-auto shrink-0 font-mono text-[10px]">
                      <span className="text-slate-500 text-[10px]">{pkt.latencyMs}ms</span>
                      <span className="text-slate-500 text-[10px]" title="Packet Bytes">{pkt.sizeBytes} B</span>
                      <span className={`px-2 py-0.5 rounded border text-[10px] ${badgeColor}`}>
                        {pkt.status.toUpperCase()} ({pkt.riskScore}%)
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          <div className="border-t border-slate-900 pt-2 mt-2 text-[10px] text-slate-400 flex items-center justify-between">
            <span>Showing real-time rolling packet logs. Click individual records to analyze.</span>
            <span>Total stored: {packets.length}</span>
          </div>

        </div>

        {/* Action Injectors & Anomaly Generator Panel */}
        <div className="lg:col-span-4 bg-slate-950 rounded-xl border border-slate-800/80 p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 border-b border-slate-900 pb-2 mb-4">
              <Sliders className="text-cyan-400" size={15} />
              <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">Engine Stimulators</h3>
            </div>
            
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Demonstrate the threat evaluation system by injecting live transaction payloads down the Pipe-and-Filter filters:
            </p>

            <div className="space-y-2.5">
              
              <button 
                onClick={injectCleanQuery}
                className="w-full flex items-center justify-between bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-200 py-2.5 px-3 rounded-lg text-xs font-bold transition cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <CheckCircle className="text-emerald-400" size={14} /> Normal Traffic Packet
                </span>
                <span className="text-[10px] font-mono text-slate-500 uppercase">Inject</span>
              </button>

              <div className="border-t border-slate-900 my-4 pt-3">
                <p className="text-[10px] font-mono text-rose-400 uppercase tracking-wider mb-2 font-bold flex items-center gap-1">
                  <span className="inline-block h-1.5 w-1.5 rounded-full bg-rose-500" /> Simulated Attack Vectors:
                </p>
                
                <div className="space-y-2">
                  <button 
                    onClick={() => injectAttackQuery('tx_hijack')}
                    className="w-full flex items-center justify-between bg-rose-950/20 hover:bg-rose-950/45 border border-rose-900/35 text-rose-200 py-2 px-3 rounded-lg text-xs font-medium transition cursor-pointer"
                  >
                    <span className="flex items-center gap-1.5">
                      <AlertTriangle className="text-rose-400" size={12} /> Transaction ID Mismatch
                    </span>
                    <span className="text-[10px] text-rose-400/80 font-mono">Simulate</span>
                  </button>

                  <button 
                    onClick={() => injectAttackQuery('ttl_hijack')}
                    className="w-full flex items-center justify-between bg-yellow-950/20 hover:bg-yellow-950/45 border border-yellow-900/35 text-yellow-200 py-2 px-3 rounded-lg text-xs font-medium transition cursor-pointer"
                  >
                    <span className="flex items-center gap-1.5">
                      <AlertTriangle className="text-yellow-400" size={12} /> Low TTL Cache Poisoning
                    </span>
                    <span className="text-[10px] text-yellow-400/80 font-mono font-bold">Simulate</span>
                  </button>

                  <button 
                    onClick={() => injectAttackQuery('mismatch')}
                    className="w-full flex items-center justify-between bg-orange-950/20 hover:bg-orange-950/45 border border-orange-900/35 text-orange-200 py-2 px-3 rounded-lg text-xs font-medium transition cursor-pointer"
                  >
                    <span className="flex items-center gap-1.5">
                      <AlertTriangle className="text-orange-400" size={12} /> Resolver Consensus Clash
                    </span>
                    <span className="text-[10px] text-orange-400/80 font-mono">Simulate</span>
                  </button>
                </div>
              </div>

            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-900 flex flex-col gap-1 text-[10px] text-slate-500 font-mono">
            <span>• Scapy Capturing Rate: <span className="text-slate-300">{simulationRate} query/sec</span></span>
            <span>• active security locks: <span className="text-slate-300">{mitigationState.hostsFileSecure ? 'Locked' : 'Standard'}</span></span>
          </div>

        </div>

      </div>

      {/* Selected Packet Inspection Panel */}
      {selectedPacket && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-5">
          <div className="flex justify-between items-center border-b border-slate-900 pb-3 mb-4">
            <h4 className="font-bold text-slate-100 text-xs uppercase tracking-wider flex items-center gap-2">
              <Eye className="text-cyan-400" size={15} /> Forensic Packet Examiner
            </h4>
            <button 
              onClick={() => setSelectedPacket(null)}
              className="text-slate-500 hover:text-slate-200 text-xs font-bold uppercase transition scale-90 cursor-pointer"
            >
              Close Forensic Panel
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            
            <div className="md:col-span-2 space-y-4 text-xs font-mono">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Transaction Address Metadata</span>
                <p className="text-slate-200 mt-1 font-semibold flex items-center gap-2">
                  <span>Domain: {selectedPacket.domain}</span>
                  <span className="bg-slate-900 border border-slate-800 text-slate-400 text-[9px] px-1 py-0.5 rounded">
                    {selectedPacket.queryType}
                  </span>
                </p>
                <p className="text-slate-400 text-[11px] mt-1">Transaction ID: <span className="text-indigo-400">0x{selectedPacket.transactionId}</span></p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Source Client IP</span>
                  <p className="text-slate-300 mt-0.5">{selectedPacket.sourceIP}</p>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase">Serving Nameserver</span>
                  <p className="text-slate-300 mt-0.5">{selectedPacket.resolverIP}</p>
                </div>
              </div>

              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Inbound Answer IP Set</span>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {selectedPacket.responseIPs.map((ip, i) => (
                    <span key={i} className="bg-slate-900/80 text-slate-200 px-2 py-0.5 rounded border border-slate-800 text-[10px]">
                      {ip}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-4 text-xs font-mono">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Time-To-Live (TTL)</span>
                <p className="text-slate-300 mt-1 flex items-baseline gap-1">
                  <span className="text-sm font-bold">{selectedPacket.ttl}</span> sec
                  {selectedPacket.baselineTTL && (
                    <span className="text-[10px] text-slate-500">(Historic baseline: {selectedPacket.baselineTTL}s)</span>
                  )}
                </p>
              </div>

              <div>
                <span className="text-slate-500 block text-[10px] uppercase">DNSSEC Authenticated</span>
                <p className={`mt-1 font-bold ${selectedPacket.dnssecValidated ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {selectedPacket.dnssecValidated ? 'SECURE (RRSIG SIGNED)' : 'UNVERIFIED / MISSING KEYS'}
                </p>
              </div>

              <div>
                <span className="text-slate-500 block text-[10px] uppercase">Engine Inspection Path</span>
                <p className="text-[10px] text-slate-400 mt-1 truncate">
                  {selectedPacket.filtersInspected.join(' ➔ ')}
                </p>
              </div>
            </div>

            <div className="space-y-2 bg-slate-900 p-4 rounded-xl border border-slate-800">
              <span className="text-slate-500 block text-[10px] uppercase font-mono">Calculated Risk Factor</span>
              <div className="flex items-baseline gap-2">
                <span className={`text-4xl font-extrabold font-mono ${
                  selectedPacket.status === 'spoofed' ? 'text-red-500 animate-pulse' : selectedPacket.status === 'suspicious' ? 'text-yellow-400' : 'text-emerald-400'
                }`}>
                  {selectedPacket.riskScore}%
                </span>
                <span className="text-[10px] text-slate-400 uppercase font-mono font-bold tracking-wider">
                  {selectedPacket.status}
                </span>
              </div>
              <div className="text-[11px] text-slate-300 leading-normal font-sans border-t border-slate-800/80 pt-2.5 mt-2">
                {selectedPacket.notes}
              </div>
            </div>

          </div>

          {/* Raw Scapy Hex Viewer Simulation */}
          <div className="bg-slate-950 text-[10px] text-slate-400 p-3 rounded-lg border border-slate-900 font-mono mt-4 leading-relaxed overflow-x-auto max-w-full">
            <span className="text-slate-500 uppercase block mb-1 text-[9px] tracking-wider">Scapy Hex Encoded Buffer Fragment (0x0000 - 0x002e)</span>
            {`0000   00 0c 29 db de ee 00 50  56 f9 a3 f8 08 00 45 00   ..)...PV .....E.\n`}
            {`0010   00 41 8c f2 00 00 40 11  98 2e c0 a8 01 69 c0 a8   .A....@. .....i..\n`}
            {`0020   01 01 cd f9 00 35 00 2d  c2 fe `}
            <span className="text-cyan-400 font-bold" title="Transaction ID Hex Value">{selectedPacket.transactionId.substring(0,2)} {selectedPacket.transactionId.substring(2)}</span>
            {` 81 80 00 01 00 01   .....5.- ..${selectedPacket.transactionId}......`}
          </div>

        </div>
      )}

    </div>
  );
}
