import React, { useState } from 'react';
import { ACADEMIC_INFO, SAD_SECTIONS, ADR_DATABASE } from '../data/sad_document';
import { 
  BookOpen, Users, FileText, Server, Cpu, ShieldAlert, 
  HelpCircle, ChevronRight, Download, Printer, ArrowLeft,
  Settings, Layers, Database, Compass, Globe, Info
} from 'lucide-react';

export default function SADViewer() {
  const [activeSection, setActiveSection] = useState<string>('introduction');
  const [printMode, setPrintMode] = useState<boolean>(false);
  const [activeScenario, setActiveScenario] = useState<number>(0);

  const scenarios = [
    {
      id: "S-01",
      title: "S-01: User monitoring start",
      desc: "User launches the PyQt6 GUI dashboard. The front-end issues an IPC signal to dnsguard-daemon which initiates the Scapy/Npcap socket capturing thread. Fresh packets populate the statistics display every 1000ms.",
      steps: ["PyQt6 GUI Start", "IPC Register client", "scapy.sniff() Launch", "Active UI Heartbeat"]
    },
    {
      id: "S-02",
      title: "S-02: DNS spoofing attack detection",
      desc: "Malicious response arrives with mismatched transaction ID and DNSSEC failure. The rule aggregator scores it at 95 (CRITICAL). AlertDispatcher broadcasts verdict, triggers OS toaster alerts, fires cache flush, and logs to SQLCipher.",
      steps: ["Packet Arrives", "IFilters Evaluate", "Verdict Score (95+)", "Toast Alert + Mitigate"]
    },
    {
      id: "S-03",
      title: "S-03: Threat Feed Hot-Reload",
      desc: "Background dnsguard-updater pulls a signed blacklist feed via HTTPS CDN. Once signature validation succeeds, it writes to sqlite. It signals dnsguard-daemon with SIGHUP to hot-reload fresh records of malicious IPs.",
      steps: ["CDN Check (24h)", "Key Signature Check", "Encrpyted Cache Update", "Hot-Reload Rules"]
    },
    {
      id: "S-04",
      title: "S-04: Resolute GUI Recovery",
      desc: "If GUI crashes under memory stress, the continuous background dnsguard-daemon remains active, sniffing packets and keeping local shields up. The daemon watchdog auto-reboots the user session and re-attaches IPC pipes.",
      steps: ["GUI Crash Detected", "Daemon Stays Active", "IPC State Buffering", "GUI Restarts & Syncs"]
    },
    {
      id: "S-05",
      title: "S-05: Offline Graceful Degradation",
      desc: "Workstation loses global WAN link. Active external Quad9/Cloudflare DoH cross-checks fail. The system falls back to strict local cryptographic DNSSEC signature validation and flags unverified records as 'unverified' with warning levels.",
      steps: ["WAN Drop Trigger", "Fallback to Local Anchors", "Crypto Chain Check Only", "Warning Badge to UI"]
    }
  ];

  if (printMode) {
    return (
      <div className="bg-white text-gray-900 p-8 max-w-4xl mx-auto shadow-lg relative min-h-screen font-serif" id="sad-print-layout">
        <div className="absolute top-6 right-6 no-print flex gap-2">
          <button 
            onClick={() => window.print()} 
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-sans font-medium transition cursor-pointer"
          >
            <Printer size={16} /> Print / Save PDF
          </button>
          <button 
            onClick={() => setPrintMode(false)}
            className="flex items-center gap-2 bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded-lg text-sm font-sans font-medium transition cursor-pointer"
          >
            <ArrowLeft size={16} /> Close Report
          </button>
        </div>

        {/* Header Cover */}
        <div className="border-b-4 border-gray-800 pb-8 mb-10 text-center font-sans">
          <p className="text-sm font-semibold uppercase tracking-widest text-[#155e75]">{ACADEMIC_INFO.institution}</p>
          <h1 className="text-3xl font-extrabold mt-4 text-gray-900">{ACADEMIC_INFO.topic}</h1>
          <h2 className="text-xl font-bold mt-1 text-gray-600">{ACADEMIC_INFO.docTitle}</h2>
          <div className="mt-4 text-sm text-gray-500 font-mono">
            {ACADEMIC_INFO.assignment} | Course Code: {ACADEMIC_INFO.code}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-6 mb-12 text-sm border-b pb-8 border-dashed font-sans">
          <div>
            <h4 className="font-bold text-gray-800 uppercase text-xs tracking-wider">Submitted By:</h4>
            <ul className="mt-2 space-y-1">
              {ACADEMIC_INFO.authors.map((author, i) => (
                <li key={i} className="text-gray-700 font-medium">
                  {author.name} <span className="text-gray-400 font-mono">(Roll: {author.rollNo})</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="text-right">
            <h4 className="font-bold text-gray-800 uppercase text-xs tracking-wider">Submitted To:</h4>
            <p className="mt-2 text-gray-700 font-medium">{ACADEMIC_INFO.instructor}</p>
            <h4 className="font-bold text-gray-800 uppercase text-xs tracking-wider mt-4">Submission Date:</h4>
            <p className="text-gray-700 font-mono">{ACADEMIC_INFO.submissionDate}</p>
          </div>
        </div>

        {/* Content Flow */}
        <div className="space-y-10 leading-relaxed text-gray-800 text-base">
          {SAD_SECTIONS.map((section) => (
            <div key={section.id} className="pt-2">
              <h3 className="text-xl font-bold border-b pb-2 text-gray-900 font-sans mb-4">{section.title}</h3>
              {section.content.map((p, idx) => (
                <p key={idx} className="mb-4 text-justify font-sans">{p}</p>
              ))}

              {section.subsections && (
                <div className="mt-4 pl-4 border-l-2 border-gray-200 space-y-4">
                  {section.subsections.map((sub, idx) => (
                    <div key={idx}>
                      <h4 className="font-semibold text-gray-900 font-sans">{sub.subtitle}</h4>
                      {sub.body && <p className="text-sm text-gray-600 mt-1 text-justify font-sans">{sub.body}</p>}
                      {sub.bullets && (
                        <ul className="list-disc list-inside mt-2 space-y-1 pl-2 text-sm text-gray-600 font-sans">
                          {sub.bullets.map((b, i) => (
                            <li key={i}>{b}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {section.id === "style" && (
                <div className="mt-6 font-sans">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="bg-gray-100 border text-left font-bold">
                        <th className="p-2 border">Style / Layer</th>
                        <th className="p-2 border">Core Benefit</th>
                        <th className="p-2 border">Challenge / Mitigation</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border">
                        <td className="p-2 border font-medium">Layered Architecture</td>
                        <td className="p-2 border text-gray-600">Separation of UI, controller, heuristics, databases</td>
                        <td className="p-2 border text-gray-600">Minor routing overhead, mitigated by clean direct queries</td>
                      </tr>
                      <tr className="border">
                        <td className="p-2 border font-medium">Pipe-and-Filter</td>
                        <td className="p-2 border text-gray-600">Independent stages parsed in streams, pluggable</td>
                        <td className="p-2 border text-gray-600">Inbound pacing buffer issues, mitigated by bound static queues</td>
                      </tr>
                      <tr className="border">
                        <td className="p-2 border font-medium">Daemon Service</td>
                        <td className="p-2 border text-gray-600">Continuous system security running as standard background daemon</td>
                        <td className="p-2 border text-gray-600">Needs OS service installers, mitigated by standard setup scripts</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              )}

              {section.id === "adr" && (
                <div className="mt-6 font-sans">
                  <table className="w-full text-xs border-collapse">
                    <thead>
                      <tr className="bg-gray-100 border text-left font-bold">
                        <th className="p-2 border">ID</th>
                        <th className="p-2 border">Decision</th>
                        <th className="p-2 border">Rationale</th>
                        <th className="p-2 border">Alternative Rejected</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ADR_DATABASE.map((adr, i) => (
                        <tr key={i} className="border">
                          <td className="p-2 border font-mono font-bold text-blue-600">{adr.id}</td>
                          <td className="p-2 border font-medium">{adr.decision}</td>
                          <td className="p-2 border text-gray-600">{adr.reason}</td>
                          <td className="p-2 border text-red-600 font-mono text-[10px]">{adr.alternative}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-16 border-t pt-8 text-center text-xs text-gray-400 font-sans">
          Hazara University, Mansehra | Course Introduction to Software Engineering (CYS122)
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-slate-900/60 rounded-xl p-6 border border-slate-800">
      
      {/* Sidebar Navigation */}
      <div className="lg:col-span-3 space-y-4">
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80">
          <div className="flex items-center gap-2 mb-3">
            <BookOpen className="text-cyan-400" size={18} />
            <h3 className="font-bold text-slate-100 text-sm tracking-wider uppercase">SAD View Index</h3>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed mb-4">
            Browse through the 4+1 views and design structures from assignment 03.
          </p>
          <div className="space-y-1">
            {SAD_SECTIONS.map((section) => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-semibold flex items-center justify-between transition ${
                  activeSection === section.id 
                    ? 'bg-cyan-950 text-cyan-400 border border-cyan-800/60' 
                    : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                }`}
              >
                <span>{section.title.split(' ')[1] || section.title}</span>
                <ChevronRight size={12} className={activeSection === section.id ? 'opacity-100' : 'opacity-40'} />
              </button>
            ))}
          </div>
        </div>

        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 space-y-3">
          <div className="flex items-center gap-2">
            <Users className="text-indigo-400" size={16} />
            <h3 className="font-bold text-slate-100 text-xs uppercase tracking-wider">Project Authors</h3>
          </div>
          <div className="space-y-2 text-xs">
            {ACADEMIC_INFO.authors.map((author, i) => (
              <div key={i} className="p-2 bg-slate-900 rounded-lg">
                <p className="font-bold text-slate-200">{author.name}</p>
                <p className="font-mono text-[10px] text-slate-500">Roll: {author.rollNo}</p>
              </div>
            ))}
            <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400">
              <span className="font-semibold">Supervised by:</span>
              <p className="text-slate-200 font-medium mt-0.5">{ACADEMIC_INFO.instructor}</p>
            </div>
          </div>
        </div>

        <button
          onClick={() => setPrintMode(true)}
          className="w-full flex items-center justify-center gap-2 bg-slate-950 hover:bg-slate-900 border border-slate-800 text-slate-200 hover:text-white py-3 rounded-lg text-xs font-bold transition duration-200 cursor-pointer"
        >
          <Printer size={14} /> Full printable report (PDF)
        </button>
      </div>

      {/* Main Core Viewer */}
      <div className="lg:col-span-9 bg-slate-950 rounded-xl border border-slate-800/80 p-6 flex flex-col justify-between">
        <div>
          {/* Header Title */}
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5 mb-6">
            <div>
              <span className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase">
                {ACADEMIC_INFO.institution.split(',')[0]}
              </span>
              <h2 className="text-2xl font-black text-slate-100 mt-1">
                {SAD_SECTIONS.find(s => s.id === activeSection)?.title}
              </h2>
            </div>
            <div className="mt-2 md:mt-0 px-3 py-1 bg-slate-900 rounded border border-slate-800 font-mono text-[10px] text-slate-400">
              CYS122 Introduction to Software Engineering
            </div>
          </div>

          {/* Section Render Blocks */}
          <div className="space-y-4">
            {SAD_SECTIONS.find(s => s.id === activeSection)?.content.map((p, idx) => (
              <p key={idx} className="text-slate-300 text-sm leading-relaxed text-justify">{p}</p>
            ))}

            {/* Logical View Interactive Panel */}
            {activeSection === 'views' && (
              <div className="mt-6 space-y-6">
                
                {/* Visual Tabs inside Logical / views */}
                <div className="bg-slate-900 rounded-xl p-4 border border-slate-800/80">
                  <h4 className="flex items-center gap-2 text-xs font-bold text-slate-200 uppercase mb-3 text-cyan-400">
                    <Layers size={14} /> Logical 4-Layers Architectural Blocks
                  </h4>
                  <div className="space-y-2 mt-2 font-mono text-xs">
                    <div className="bg-cyan-950/40 p-3 rounded-lg border border-cyan-800/50">
                      <p className="text-cyan-400 font-bold mb-1">[1] Presentation / UI Layer</p>
                      <div className="flex flex-wrap gap-2 text-[10px]">
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">PyQt6 Dashboard</span>
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">Alert Center Center</span>
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">SAD Reports Engine</span>
                      </div>
                    </div>
                    <div className="bg-indigo-950/40 p-3 rounded-lg border border-indigo-800/50">
                      <p className="text-indigo-400 font-bold mb-1">[2] Application Controller</p>
                      <div className="flex flex-wrap gap-2 text-[10px]">
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">Main Daemon Client</span>
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">IPC NamedPipe Listener</span>
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">AlertDispatcher Bus</span>
                      </div>
                    </div>
                    <div className="bg-emerald-950/40 p-3 rounded-lg border border-emerald-800/50">
                      <p className="text-emerald-400 font-bold mb-1">[3] Heuristics Domain Layer</p>
                      <div className="flex flex-wrap gap-2 text-[10px]">
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">Cryptographic DNSSEC</span>
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">Multi-Resolver Verifier</span>
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">Mitigations Engine</span>
                      </div>
                    </div>
                    <div className="bg-pink-950/40 p-3 rounded-lg border border-pink-800/50">
                      <p className="text-pink-400 font-bold mb-1">[4] Core Infrastructure</p>
                      <div className="flex flex-wrap gap-2 text-[10px]">
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">Raw Scapy Sockets</span>
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">SQLCipher Encrypted DB</span>
                        <span className="bg-slate-900 px-2 py-1 rounded text-slate-300 border border-slate-800">OS Route Hooks</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* S-X Event Scenarios Panel */}
                <div className="bg-slate-900 rounded-xl p-5 border border-slate-800">
                  <div className="flex justify-between items-center mb-4">
                    <h4 className="flex items-center gap-2 text-xs font-bold text-slate-200 uppercase text-indigo-400">
                      <Compass size={14} /> (+1) Architectural Scenarios Stepper
                    </h4>
                    <div className="flex gap-1">
                      {scenarios.map((s, idx) => (
                        <button
                          key={s.id}
                          onClick={() => setActiveScenario(idx)}
                          className={`px-2 py-1 text-[10px] font-mono rounded font-bold transition ${
                            activeScenario === idx 
                              ? 'bg-indigo-600 text-white' 
                              : 'bg-slate-950 text-slate-500 hover:text-slate-300'
                          }`}
                        >
                          {s.id}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-slate-950 p-4 rounded-lg border border-slate-800">
                    <p className="text-slate-100 font-bold text-xs">{scenarios[activeScenario].title}</p>
                    <p className="text-slate-400 text-xs mt-2 leading-relaxed">{scenarios[activeScenario].desc}</p>
                    
                    <div className="mt-4 pt-4 border-t border-slate-800">
                      <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mb-2">Process Sequence Nodes:</p>
                      <div className="grid grid-cols-4 gap-2">
                        {scenarios[activeScenario].steps.map((st, i) => (
                          <div key={i} className="bg-slate-900 p-2 rounded border border-slate-850 text-center flex flex-col items-center justify-center">
                            <span className="text-[10px] font-semibold text-slate-400 block mb-0.5 font-mono">0{i+1}</span>
                            <span className="text-[10px] text-indigo-300 font-medium leading-tight">{st}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* Custom Layouts for Architectural Decisions */}
            {activeSection === 'adr' && (
              <div className="mt-4 space-y-3">
                {ADR_DATABASE.map((adr, idx) => (
                  <div key={idx} className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex flex-col md:flex-row md:items-start gap-4">
                    <div className="bg-slate-950 text-indigo-400 border border-slate-800 font-mono px-3 py-1 rounded-md text-xs font-bold shrink-0 text-center">
                      {adr.id}
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-200">{adr.decision}</h4>
                      <p className="text-xs text-slate-400 mt-1">{adr.reason}</p>
                      <p className="text-[10px] font-mono text-rose-400 mt-2">
                        <span className="text-slate-500">Rejected Alternative:</span> {adr.alternative}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Subsections Renderer if any */}
            {SAD_SECTIONS.find(s => s.id === activeSection)?.subsections?.map((sub, idx) => (
              <div key={idx} className="bg-slate-900/40 rounded-xl p-4 border border-slate-850 mt-4">
                <h4 className="text-xs font-bold text-slate-200 uppercase mb-2 text-cyan-400">{sub.subtitle}</h4>
                {sub.body && <p className="text-xs text-slate-400 leading-relaxed">{sub.body}</p>}
                {sub.bullets && (
                  <ul className="list-disc list-inside mt-2 space-y-1.5 text-xs text-slate-400 pl-1 leading-normal">
                    {sub.bullets.map((b, i) => (
                      <li key={i}>{b}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Navigation */}
        <div className="mt-8 border-t border-slate-800/80 pt-4 flex justify-between text-xs text-slate-500 font-mono items-center">
          <div className="flex items-center gap-2">
            <Info size={14} className="text-slate-400 hover:text-cyan-400 cursor-pointer" />
            <span>Hazara University • Assignment 03</span>
          </div>
          <span className="hidden sm:inline">Introduction to Software Engineering</span>
        </div>

      </div>
    </div>
  );
}
