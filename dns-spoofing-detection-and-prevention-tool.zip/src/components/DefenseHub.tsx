import React, { useState } from 'react';
import { 
  ShieldCheck, ShieldAlert, KeyRound, Server, Trash2, 
  RotateCcw, Sliders, Play, Check, Database, FileText,
  AlertTriangle, Lock, Unlock, HelpCircle, HardDrive
} from 'lucide-react';
import { DNSPacket, SystemLogEntry } from '../types';

interface DefenseHubProps {
  packets: DNSPacket[];
  mitigationState: { dnsCacheFlushed: boolean; dohForced: boolean; firewallRulesCount: number; hostsFileSecure: boolean };
  onUpdateMitigation: (key: 'dnsCacheFlushed' | 'dohForced' | 'firewallRulesCount' | 'hostsFileSecure', value: any) => void;
  systemLogs: SystemLogEntry[];
  onAddSystemLog: (comp: 'Daemon' | 'GUI' | 'Updater' | 'Mitigator', lvl: 'info' | 'warning' | 'error' | 'success', msg: string) => void;
  onClearLogs: () => void;
}

export default function DefenseHub({
  packets,
  mitigationState,
  onUpdateMitigation,
  systemLogs,
  onAddSystemLog,
  onClearLogs
}: DefenseHubProps) {
  const [dbTable, setDbTable] = useState<'alerts' | 'firewall' | 'system_logs'>('alerts');
  const [isFlushing, setIsFlushing] = useState<boolean>(false);

  // Trigger Cache Flush simulator
  const handleFlushCache = () => {
    setIsFlushing(true);
    onAddSystemLog('Mitigator', 'info', 'Triggering system-wide resolver cache flush script (IPC daemon-hook).');
    
    setTimeout(() => {
      onUpdateMitigation('dnsCacheFlushed', true);
      setIsFlushing(false);
      onAddSystemLog('Mitigator', 'success', 'DNS cache flush reports completion. Cleared ipconfig/hosts resolver local caches.');
    }, 1200);
  };

  // Toggle DoH
  const handleToggleDoH = () => {
    const nextState = !mitigationState.dohForced;
    onUpdateMitigation('dohForced', nextState);
    if (nextState) {
      onAddSystemLog('Mitigator', 'success', 'DoH forced tunnel enabled on RFC 8484 targets. Encrypting traffic via Cloudflare DoH.');
    } else {
      onAddSystemLog('Mitigator', 'warning', 'Enforced DoH disabled. Reverted to standard ISP plain DNS UDP port 53 lookup pathways.');
    }
  };

  // Toggle Hosts lock
  const handleToggleHostsLock = () => {
    const nextState = !mitigationState.hostsFileSecure;
    onUpdateMitigation('hostsFileSecure', nextState);
    if (nextState) {
      onAddSystemLog('Mitigator', 'success', 'Hosts file write locks engaged. Set read-only permission attributes (chattr +i /etc/hosts).');
    } else {
      onAddSystemLog('Mitigator', 'info', 'Hosts file permission bits released for local environment updates.');
    }
  };

  // Trigger quick firewall rule injection
  const handleAddFirewallRule = () => {
    const nextCount = mitigationState.firewallRulesCount + 1;
    onUpdateMitigation('firewallRulesCount', nextCount);
    onAddSystemLog('Mitigator', 'success', `Injected outbound firewall block rule #${nextCount} blocking malicious destination nodes.`);
  };

  // Clear all firewall rules
  const handleClearFirewallRules = () => {
    onUpdateMitigation('firewallRulesCount', 0);
    onAddSystemLog('Mitigator', 'info', 'Flushed all custom DNSGuard mitigation firewall rules.');
  };

  // Count active incidents in SQLCipher
  const incidentsCount = packets.filter(p => p.status === 'spoofed').length;

  return (
    <div className="space-y-6">
      
      {/* Mitigation Action Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* Active Defense Dashboard Controls */}
        <div className="md:col-span-4 bg-slate-950 p-5 rounded-xl border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 border-b border-slate-900 pb-2 mb-4">
              <ShieldCheck className="text-[#10b981]" size={16} />
              <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">Active Shields Hub</h3>
            </div>

            <p className="text-xs text-slate-400 leading-normal mb-5">
              Execute low-latency OS integration hooks immediately to isolate the workstation resolver and clean current caching buffers.
            </p>

            <div className="space-y-3.5">
              
              {/* Lock hosts toggle */}
              <div className="flex items-center justify-between bg-slate-900 p-3 rounded-xl border border-slate-800">
                <div>
                  <label className="text-slate-200 text-xs font-bold block flex items-center gap-1.5">
                    {mitigationState.hostsFileSecure ? <Lock size={12} className="text-[#10b981]" /> : <Unlock size={12} className="text-amber-500" />}
                    Hosts File Shield
                  </label>
                  <span className="text-[10px] text-slate-500 font-mono">Immutable ACL limits</span>
                </div>
                <button
                  onClick={handleToggleHostsLock}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    mitigationState.hostsFileSecure 
                      ? 'bg-[#10b981]/15 text-[#10b981] border border-emerald-800/40' 
                      : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-250'
                  }`}
                >
                  {mitigationState.hostsFileSecure ? 'Locked' : 'Unlock'}
                </button>
              </div>

              {/* Force DoH toggle */}
              <div className="flex items-center justify-between bg-slate-900 p-3 rounded-xl border border-slate-800">
                <div>
                  <label className="text-slate-200 text-xs font-bold block flex items-center gap-1.5">
                    <Sliders size={12} className="text-cyan-400" />
                    Forced DoH Tunnel
                  </label>
                  <span className="text-[10px] text-slate-500 font-mono">Encrypt DNS via HTTPS</span>
                </div>
                <button
                  onClick={handleToggleDoH}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    mitigationState.dohForced 
                      ? 'bg-cyan-950/40 text-cyan-400 border border-cyan-800/65' 
                      : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-250'
                  }`}
                >
                  {mitigationState.dohForced ? 'Active' : 'Deploy'}
                </button>
              </div>

              {/* Flush DNS cache */}
              <button
                onClick={handleFlushCache}
                disabled={isFlushing}
                className="w-full flex items-center justify-between bg-slate-900 border border-slate-800 hover:bg-slate-850 py-2.5 px-3.5 rounded-xl text-xs font-bold text-slate-200 transition cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <RotateCcw size={12} className={`text-indigo-400 ${isFlushing ? 'animate-spin' : ''}`} />
                  Flush DNS Resolver Cache
                </span>
                <span className="text-[10px] font-mono text-slate-500 uppercase">{isFlushing ? 'processing' : 'run'}</span>
              </button>

            </div>
          </div>

          <div className="border-t border-slate-900 pt-3 mt-4 text-[10px] text-slate-500 font-mono leading-relaxed">
            Infrastructure Hooks: <br />
            <span className="text-slate-400">Windows (Npcap & ipconfig) <br /> Linux/macOS (iptables & systemd-resolved)</span>
          </div>

        </div>

        {/* Firewall Sandbox block */}
        <div className="md:col-span-4 bg-slate-950 p-5 rounded-xl border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 border-b border-slate-900 pb-2 mb-4">
              <ShieldAlert className="text-amber-500" size={16} />
              <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">Firewall Interceptor</h3>
            </div>

            <p className="text-xs text-slate-400 leading-normal mb-4">
              Block compromised IP destinations detected during spoofing attempts by writing immediate local routing filter definitions.
            </p>

            <div className="bg-slate-900 border border-slate-850 rounded-xl p-4 mb-4 text-center">
              <p className="text-[10px] font-mono text-slate-500 uppercase">Active Netsh/iptables Rules</p>
              <h2 className="text-4xl font-black text-slate-100 font-mono mt-1">{mitigationState.firewallRulesCount}</h2>
              <p className="text-[10px] text-slate-400 mt-2 truncate">Isolated spoof destination IPs</p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleAddFirewallRule}
                className="bg-[#10b981]/10 text-[#10b981] border border-emerald-800/30 hover:bg-[#10b981]/25 py-2 px-3 rounded-lg text-xs font-bold transition cursor-pointer"
              >
                + Block IP
              </button>
              <button
                onClick={handleClearFirewallRules}
                disabled={mitigationState.firewallRulesCount === 0}
                className="bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-slate-100 py-2 px-3 rounded-lg text-xs font-bold transition duration-200 cursor-pointer disabled:opacity-30 disabled:pointer-events-none"
              >
                Flush Rules
              </button>
            </div>
          </div>

          <p className="text-[9px] font-mono text-slate-500 leading-normal mt-4">
            * Firewall scripts are triggered automatically when a packets risk exceeds the heuristics threshold set in the configuration rules.
          </p>
        </div>

        {/* Database statistics Summary (SQLCipher) */}
        <div className="md:col-span-4 bg-slate-950 p-5 rounded-xl border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 border-b border-slate-900 pb-2 mb-4">
              <Database className="text-indigo-400" size={16} />
              <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">SQLCipher Store Summary</h3>
            </div>
            
            <p className="text-xs text-slate-400 leading-normal mb-4">
              Encrypted, embedded zero-admin database (ADR-3) records continuous event statistics at rest using AES-256 block cryptos.
            </p>

            <div className="space-y-2 font-mono text-xs">
              <div className="flex justify-between items-center py-1 border-b border-slate-900">
                <span className="text-slate-500">Database Engine:</span>
                <span className="text-slate-300">SQLite 3 + SQLCipher</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-900">
                <span className="text-slate-500">Encrypted Mode:</span>
                <span className="text-[#10b981] font-bold">AES-256 HMAC</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-900">
                <span className="text-slate-500">Persisted Alerts:</span>
                <span className="text-rose-400 font-bold">{incidentsCount} record(s)</span>
              </div>
              <div className="flex justify-between items-center py-1 border-b border-slate-900">
                <span className="text-slate-500">Heuristic logs:</span>
                <span className="text-slate-300">{systemLogs.length} entries</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 p-2.5 rounded-lg border border-slate-850 text-[10px] text-slate-400 font-mono mt-4 flex items-center gap-1.5 leading-snug">
            <HardDrive size={12} className="text-cyan-400" />
            <span>Path: `%ProgramData%/DNSGuard/data.db`</span>
          </div>
        </div>

      </div>

      {/* SQLCipher Interactive database browser simulation */}
      <div className="bg-slate-950 rounded-xl border border-slate-800/80 p-5">
        
        <div className="flex flex-col sm:flex-row justify-between sm:items-center border-b border-slate-900 pb-3 mb-4 gap-2">
          
          <div className="flex items-center gap-2">
            <Database className="text-indigo-400" size={15} />
            <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">
              Encrypted DB Explorer (SQLCipher)
            </h3>
          </div>

          {/* Interactive table switcher selectors */}
          <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
            <button
              onClick={() => setDbTable('alerts')}
              className={`px-3 py-1 rounded text-[10px] font-mono uppercase font-bold transition duration-150 cursor-pointer ${
                dbTable === 'alerts' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              table: alert_history
            </button>
            <button
              onClick={() => setDbTable('firewall')}
              className={`px-3 py-1 rounded text-[10px] font-mono uppercase font-bold transition duration-150 cursor-pointer ${
                dbTable === 'firewall' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              table: firewall_isolated
            </button>
            <button
              onClick={() => setDbTable('system_logs')}
              className={`px-3 py-1 rounded text-[10px] font-mono uppercase font-bold transition duration-150 cursor-pointer ${
                dbTable === 'system_logs' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              table: logging_journal
            </button>
          </div>

        </div>

        {/* Database table records */}
        <div className="overflow-x-auto select-none border border-slate-900 rounded-lg max-w-full">
          {dbTable === 'alerts' ? (
            <table className="w-full text-xs font-mono text-left text-slate-400 border-collapse">
              <thead>
                <tr className="bg-slate-900 text-slate-300 font-bold border-b border-slate-900 text-[10px] uppercase">
                  <th className="p-2 border-r border-slate-900 w-12 text-center">ID</th>
                  <th className="p-2 border-r border-slate-900">TIMESTOP</th>
                  <th className="p-2 border-r border-slate-900">RECOG_DOMAIN</th>
                  <th className="p-2 border-r border-slate-900 text-center">TX_ID</th>
                  <th className="p-2 border-r border-slate-900 text-center">RISK_SCORE</th>
                  <th className="p-2">NOTES_FIELD</th>
                </tr>
              </thead>
              <tbody>
                {packets.filter(p => p.status === 'spoofed').length === 0 ? (
                  <tr className="border-b border-slate-900">
                    <td colSpan={6} className="p-8 text-center text-slate-650 italic">
                      No matching rows in `alert_history` table (Zero spoofing events recorded).
                    </td>
                  </tr>
                ) : (
                  packets.filter(p => p.status === 'spoofed').map((p, index) => (
                    <tr key={p.id} className="border-b border-slate-900 hover:bg-slate-900/15 text-[11px] text-slate-300">
                      <td className="p-2 border-r border-slate-900 text-center text-slate-500">{index + 1}</td>
                      <td className="p-2 border-r border-slate-900 text-slate-400 truncate max-w-[90px]">{p.timestamp}</td>
                      <td className="p-2 border-r border-slate-900 text-cyan-400 truncate max-w-[150px]">{p.domain}</td>
                      <td className="p-2 border-r border-slate-900 text-center text-slate-400 font-bold">0x{p.transactionId}</td>
                      <td className="p-2 border-r border-slate-900 text-center text-red-500 font-bold">{p.riskScore}%</td>
                      <td className="p-2 truncate max-w-[280px]" title={p.notes}>{p.notes}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          ) : dbTable === 'firewall' ? (
            <table className="w-full text-xs font-mono text-left text-slate-400 border-collapse">
              <thead>
                <tr className="bg-slate-900 text-slate-300 font-bold border-b border-slate-900 text-[10px] uppercase">
                  <th className="p-2 border-r border-slate-900 w-12 text-center">ID</th>
                  <th className="p-2 border-r border-slate-900">RULE_TARGET_IP</th>
                  <th className="p-2 border-r border-slate-900">STATUS</th>
                  <th className="p-2 border-r border-slate-900">CHAIN</th>
                  <th className="p-2">DEPLOYED_DATE</th>
                </tr>
              </thead>
              <tbody>
                {mitigationState.firewallRulesCount === 0 ? (
                  <tr className="border-b border-slate-900">
                    <td colSpan={5} className="p-8 text-center text-slate-650 italic">
                      No active firewalls recorded inside `firewall_isolated`.
                    </td>
                  </tr>
                ) : (
                  Array.from({ length: mitigationState.firewallRulesCount }).map((_, i) => (
                    <tr key={i} className="border-b border-slate-900 hover:bg-slate-900/15 text-[11px] text-slate-300">
                      <td className="p-2 border-r border-slate-900 text-center text-slate-500">{i + 1}</td>
                      <td className="p-2 border-r border-slate-900 text-red-400">198.51.100.{40 + i + 1}</td>
                      <td className="p-2 border-r border-slate-900 text-[#10b981] font-bold">ENFORCED</td>
                      <td className="p-2 border-r border-slate-900">OUTPUT_DROP</td>
                      <td className="p-2 text-slate-400">2026-06-06 09:12 UTC</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          ) : (
            <div className="max-h-60 overflow-y-auto w-full">
              <table className="w-full text-xs font-mono text-left text-slate-400 border-collapse">
                <thead>
                  <tr className="bg-slate-900 text-slate-300 font-bold border-b border-slate-900 text-[10px] uppercase">
                    <th className="p-2 border-r border-slate-900 w-12 text-center">ID</th>
                    <th className="p-2 border-r border-slate-900">COMP_NODE</th>
                    <th className="p-2 border-r border-slate-900 text-center">LEVEL</th>
                    <th className="p-2">LOG_MESSAGE_TEXT</th>
                  </tr>
                </thead>
                <tbody>
                  {systemLogs.length === 0 ? (
                    <tr className="border-b border-slate-900">
                      <td colSpan={4} className="p-8 text-center text-slate-650 italic">
                        No logging entries compiled in buffer directory.
                      </td>
                    </tr>
                  ) : (
                    [...systemLogs].reverse().slice(0, 30).map((log, i) => {
                      let lvlColor = 'text-slate-400';
                      if (log.level === 'success') lvlColor = 'text-emerald-400';
                      if (log.level === 'warning') lvlColor = 'text-yellow-400';
                      if (log.level === 'error') lvlColor = 'text-red-500 font-bold';
                      return (
                        <tr key={log.id} className="border-b border-slate-900 hover:bg-slate-900/15 text-[11px] text-slate-300">
                          <td className="p-2 border-r border-slate-900 text-center text-slate-500">{i + 1}</td>
                          <td className="p-2 border-r border-slate-900 text-slate-400">{log.component}</td>
                          <td className={`p-2 border-r border-slate-900 text-center ${lvlColor}`}>{log.level.toUpperCase()}</td>
                          <td className="p-2 leading-tight text-slate-300 truncate max-w-[340px] sm:max-w-none" title={log.message}>{log.message}</td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono mt-3">
          <span>Simulation Mode: Read-Only SQLCipher mirror tables. Sync: Auto.</span>
          <button 
            onClick={onClearLogs}
            className="text-slate-500 hover:text-slate-300 font-bold cursor-pointer"
          >
            Clear Logging DB
          </button>
        </div>

      </div>

    </div>
  );
}
