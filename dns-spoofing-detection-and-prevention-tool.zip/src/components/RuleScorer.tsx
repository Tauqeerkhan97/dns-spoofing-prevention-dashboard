import React from 'react';
import { RuleWeights } from '../types';
import { 
  Sliders, RefreshCw, CircleAlert, Sparkles, BookOpen, 
  Settings, Zap, CheckCircle 
} from 'lucide-react';

interface RuleScorerProps {
  weights: RuleWeights;
  onUpdateWeight: (key: keyof RuleWeights, value: number) => void;
  onResetWeights: () => void;
  onAddSystemLog: (comp: 'Daemon' | 'GUI' | 'Updater' | 'Mitigator', lvl: 'info' | 'warning' | 'error' | 'success', msg: string) => void;
}

export default function RuleScorer({
  weights,
  onUpdateWeight,
  onResetWeights,
  onAddSystemLog
}: RuleScorerProps) {

  const handleSliderChange = (key: keyof RuleWeights, val: number) => {
    onUpdateWeight(key, val);
  };

  const handleReset = () => {
    onResetWeights();
    onAddSystemLog('GUI', 'info', 'Reverted DNSGuard scoring engines to default design baselines.');
  };

  // Human descriptive text for each score weight
  const ruleMeta: { key: keyof RuleWeights; title: string; description: string; impact: string }[] = [
    {
      key: 'txIdMismatch',
      title: 'DNS Transaction ID (TxID) Mismatch',
      description: 'Incoming DNS answers are matched against original requesting headers. Direct variations imply malicious blind response injection attempts racing against the real nameserver.',
      impact: 'Critical Hijacking Indicator'
    },
    {
      key: 'dnssecMissing',
      title: 'Cryptographic DNSSEC Signature Failed',
      description: 'Validation failures across RRSIG signatures or absent DS/DNSKEY cryptographic authentication chains when resolving secure namespaces.',
      impact: 'Crypto Fraud/Tampering Indicator'
    },
    {
      key: 'blacklistMatch',
      title: 'Threat Intel Blocklist Match',
      description: 'Domains requested intersect with active local SQLite database indicators synchronized via real-time signed intelligence feeds.',
      impact: 'Verified Malware Gateway'
    },
    {
      key: 'ipGeoMismatch',
      title: 'Multipath DoH Resolver Consensus Clash',
      description: 'Local gateway response IPs are cross-checked through encrypted, public tunnels out to Google, Cloudflare, and Quad9. Divergence indicates local ISP router redirection.',
      impact: 'In-Path Redirection Detection'
    },
    {
      key: 'ttlAnomaly',
      title: 'Time-To-Live (TTL) Dynamic Drop Anomaly',
      description: 'Evaluates the incoming TTL against historical caches. Severe drops (e.g. from 3600s down to 2s) signal potential active DNS spoof hopping behavior.',
      impact: 'Dynamic Cache Poisoning Signal'
    },
    {
      key: 'untrustedResolver',
      title: 'Untrusted/Unverified Local Gateways',
      description: 'Resolutions delivered by unregistered local gateway endpoints or DNS redirectors without cryptographic trust anchors.',
      impact: 'Unverified Gateway Warnings'
    }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      {/* Visual Weights Sliders */}
      <div className="lg:col-span-8 bg-slate-950 rounded-xl border border-slate-805 p-5 flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center border-b border-slate-900 pb-2.5 mb-5">
            <div className="flex items-center gap-2">
              <Sliders className="text-[#10b981]" size={16} />
              <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">Heuristic Scoring Weights</h3>
            </div>
            <button
              onClick={handleReset}
              className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-850 text-slate-300 font-mono text-[10px] uppercase font-bold px-2.5 py-1.5 rounded-lg border border-slate-800 transition cursor-pointer"
            >
              <RefreshCw size={11} /> Revert Baselines
            </button>
          </div>

          <p className="text-xs text-slate-400 mb-5 leading-relaxed">
            Configure weighted danger modifiers applied to captured packets in real-time. If the cumulative score exceeds <span className="text-rose-400 font-bold font-mono">65%</span>, a formal <b>Spoof Alert</b> engages custom firewall filters and system-wide mitigations.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ruleMeta.map((rule) => (
              <div key={rule.key} className="bg-slate-900/60 p-4 rounded-xl border border-slate-850 text-xs flex flex-col justify-between h-44 hover:border-slate-800 transition">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <h4 className="font-bold text-slate-100 pr-2 truncate text-xs">{rule.title}</h4>
                    <span className="text-[10px] font-mono text-cyan-400 shrink-0 font-bold">+{weights[rule.key]}%</span>
                  </div>
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">{rule.impact}</span>
                  <p className="text-[10.5px] text-slate-400 mt-2 leading-relaxed line-clamp-3">{rule.description}</p>
                </div>

                <div className="mt-4 pt-2 border-t border-slate-850 flex items-center gap-3">
                  <input
                    type="range"
                    min="5"
                    max="80"
                    step="5"
                    value={weights[rule.key]}
                    onChange={(e) => handleSliderChange(rule.key, Number(e.target.value))}
                    className="w-full accent-[#10b981] bg-slate-950 h-1.5 rounded outline-none"
                  />
                  <span className="text-slate-200 text-xs font-mono font-bold shrink-0 w-8 text-right">{weights[rule.key]}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="border-t border-slate-900 pt-3 text-[10px] text-slate-500 font-mono flex justify-between items-center mt-6">
          <span>Active parameters: 6 independent weights</span>
          <span>Engine type: Weighted Sum Scoring (RFC compliant)</span>
        </div>

      </div>

      {/* Rationale and Mathematical logic console */}
      <div className="lg:col-span-4 bg-slate-950 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 border-b border-slate-900 pb-2 mb-4">
            <BookOpen className="text-indigo-400" size={15} />
            <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">Mathematical Rationale</h3>
          </div>

          <p className="text-xs text-slate-400 leading-normal mb-4 text-justify">
            DNSGuard aggregates independent heuristic evaluations down an additive penalty model. The cumulative probability is bounded between 0% and 100%.
          </p>

          <div className="bg-slate-900 rounded-xl p-4 border border-slate-850 space-y-4">
            <div>
              <span className="text-slate-500 block text-[9px] font-mono uppercase tracking-widest leading-none">Scoring Logic Algebraic Formula</span>
              <div className="bg-slate-950 p-2.5 rounded border border-slate-900 text-center font-mono my-2.5 select-all">
                <p className="text-cyan-400 text-xs font-bold leading-normal">
                  R = Math.min(<br />
                  &nbsp;&nbsp;Σ (A_i * W_i),<br />
                  &nbsp;&nbsp;100<br />
                  )
                </p>
              </div>
              <p className="text-[10px] text-slate-400 leading-normal">
                Where <span className="text-[#10b981] font-bold">A_i</span> is the binary anomaly verdict (0 or 1) produced by filter stages, and <span className="text-cyan-400 font-bold">W_i</span> represents corresponding weights configured on the left.
              </p>
            </div>

            <div className="border-t border-slate-800/80 pt-3 mt-3">
              <span className="text-slate-500 block text-[9px] font-mono uppercase tracking-widest leading-none mb-2">Sensitivity Matrix Levels</span>
              <div className="space-y-2 text-xs font-mono">
                <div className="flex justify-between items-center">
                  <span className="text-[#10b981] font-bold">0% - 34%</span>
                  <span className="text-slate-400">CLEAN (Verified Frame)</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-yellow-400 font-bold">35% - 64%</span>
                  <span className="text-slate-400">SUSPICIOUS (Telemetry Log)</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-red-500 font-bold">65% - 100%</span>
                  <span className="text-slate-400">SPOOFED (Active Defense)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-850 text-[10px] text-slate-400 font-mono flex items-center gap-1.5 h-12 leading-snug mt-4">
          <Zap size={14} className="text-indigo-400 flex-shrink-0" />
          <span>Real-time recalibration completes internally in &lt; 1μs on weight change.</span>
        </div>
      </div>

    </div>
  );
}
