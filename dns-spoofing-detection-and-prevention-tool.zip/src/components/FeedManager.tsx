import React, { useState } from 'react';
import { 
  ShieldAlert, RefreshCw, PlusCircle, Trash2, Check,
  AlertOctagon, Info, Sparkles, Filter 
} from 'lucide-react';
import { ThreatFeedItem } from '../types';

interface FeedManagerProps {
  threatFeeds: ThreatFeedItem[];
  onAddFeedItem: (item: ThreatFeedItem) => void;
  onRemoveFeedItem: (id: string) => void;
  onSyncFeeds: () => void;
  onAddSystemLog: (comp: 'Daemon' | 'GUI' | 'Updater' | 'Mitigator', lvl: 'info' | 'warning' | 'error' | 'success', msg: string) => void;
}

export default function FeedManager({
  threatFeeds,
  onAddFeedItem,
  onRemoveFeedItem,
  onSyncFeeds,
  onAddSystemLog
}: FeedManagerProps) {
  const [newDomain, setNewDomain] = useState<string>('');
  const [newType, setNewType] = useState<string>('Phishing & Mimic');
  const [newDanger, setNewDanger] = useState<'low' | 'medium' | 'high'>('high');
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Sync with Cloud DNS blocklist provider
  const handleSyncFeeds = () => {
    setIsSyncing(true);
    onAddSystemLog('Updater', 'info', 'Connecting to global public CDN threat-feed feeds.');
    
    setTimeout(() => {
      onSyncFeeds();
      setIsSyncing(false);
      onAddSystemLog('Updater', 'success', 'Successfully pulled signed global blocklist catalog. 2,410 rules loaded.');
    }, 1500);
  };

  // Add new blocklist entry
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDomain.trim()) return;

    const domainClean = newDomain.trim().toLowerCase();

    // Prevent duplicate additions
    if (threatFeeds.some(f => f.domain === domainClean)) {
      onAddSystemLog('GUI', 'warning', `Domain ${domainClean} is already registered inside active threat indices.`);
      return;
    }

    const item: ThreatFeedItem = {
      id: `feed_${Date.now()}`,
      domain: domainClean,
      type: newType,
      addedDate: new Date().toLocaleDateString('en-GB'),
      source: 'User Manual Entry',
      dangerLevel: newDanger,
      active: true
    };

    onAddFeedItem(item);
    onAddSystemLog('Updater', 'success', `Injected blacklisted target [${domainClean}] to local SQLite threat indicators.`);
    setNewDomain('');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      {/* List representation */}
      <div className="lg:col-span-8 bg-slate-950 rounded-xl border border-slate-800 p-5 flex flex-col justify-between h-[450px]">
        <div>
          <div className="flex justify-between items-center border-b border-slate-900 pb-2.5 mb-4">
            <div className="flex items-center gap-2">
              <ShieldAlert className="text-red-500" size={16} />
              <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">Active Threat Intelligence feeds</h3>
            </div>
            <button
              onClick={handleSyncFeeds}
              disabled={isSyncing}
              className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-850 text-slate-300 font-mono text-[10px] uppercase font-bold px-2.5 py-1.5 rounded-lg border border-slate-800 cursor-pointer"
            >
              <RefreshCw size={11} className={isSyncing ? 'animate-spin text-cyan-400' : ''} />
              {isSyncing ? 'Synchronizing...' : 'Sync Feeds (CDN)'}
            </button>
          </div>

          <div className="overflow-y-auto max-h-[310px] pr-1 space-y-1.5 scrollbar-thin">
            {threatFeeds.length === 0 ? (
              <div className="p-10 border border-slate-900 text-center italic text-slate-600 rounded text-xs select-none">
                No active domains currently blocked. ClickCDN Synchronization or enter rules on the right.
              </div>
            ) : (
              threatFeeds.map((feed) => {
                let badgeClass = 'text-green-500 bg-green-950/20 border-green-900/40';
                if (feed.dangerLevel === 'medium') badgeClass = 'text-yellow-400 bg-yellow-950/20 border-yellow-900/40';
                if (feed.dangerLevel === 'high') badgeClass = 'text-red-500 bg-red-950/20 border-red-900/40';

                return (
                  <div key={feed.id} className="p-3 bg-slate-900 border border-slate-850 rounded-lg flex items-center justify-between text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-slate-200 font-semibold text-xs leading-none">{feed.domain}</span>
                        <span className={`px-1.5 py-0.5 rounded border text-[9px] font-bold ${badgeClass}`}>
                          {feed.dangerLevel.toUpperCase()}
                        </span>
                      </div>
                      <div className="flex gap-4 text-[10px] text-slate-500 mt-1 font-mono">
                        <span>Category: <span className="text-slate-400">{feed.type}</span></span>
                        <span>Source: <span className="text-slate-400">{feed.source}</span></span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onRemoveFeedItem(feed.id);
                        onAddSystemLog('Updater', 'info', `Removed ${feed.domain} from blacklist threat index.`);
                      }}
                      className="text-slate-500 hover:text-red-400 p-1.5 rounded bg-slate-950 hover:bg-rose-950/20 border border-slate-850 transition cursor-pointer"
                      title="Remove domain blacklisted"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>

        <div className="border-t border-slate-900 pt-3 text-[10px] text-slate-500 font-mono flex justify-between items-center mt-4">
          <span>Active local rules in database: {threatFeeds.length} items</span>
          <span>Updater Sync Frequency: 24h</span>
        </div>

      </div>

      {/* manual addition side */}
      <div className="lg:col-span-4 bg-slate-950 border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-900 pb-2 mb-2">
            <PlusCircle className="text-cyan-400" size={15} />
            <h3 className="font-bold text-slate-100 text-xs tracking-wider uppercase">Append Blocklist Target</h3>
          </div>

          <p className="text-xs text-slate-400 leading-normal">
            Directly register threat indicators into the active database block. Incoming requests heading to these nodes will instantly receive the `threat blacklist` scoring modifier of +45%.
          </p>

          <div className="space-y-1.5 shadow-sm">
            <label className="text-slate-300 font-mono text-[10px] uppercase block">Malicious Domain Name:</label>
            <input
              type="text"
              required
              placeholder="e.g. evil-phishing-host.com"
              value={newDomain}
              onChange={(e) => setNewDomain(e.target.value)}
              className="w-full bg-slate-900 text-slate-200 border border-slate-800 rounded-lg py-2 px-3 text-xs outline-none focus:border-cyan-800/60 font-mono placeholder:text-slate-600"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-slate-300 font-mono text-[10px] uppercase block">Target threat class:</label>
            <select
              value={newType}
              onChange={(e) => setNewType(e.target.value)}
              className="w-full bg-slate-900 text-slate-200 border border-slate-800 rounded-lg py-2 px-3 text-xs outline-none focus:border-cyan-800/60 font-mono"
            >
              <option>Phishing & Mimic</option>
              <option>Command & Control (C2)</option>
              <option>Spam Distribution</option>
              <option>Unsigned Gateway Host</option>
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-slate-300 font-mono text-[10px] uppercase block">Assigned Severity Level:</label>
            <div className="grid grid-cols-3 gap-2 text-xs font-mono font-bold">
              <button
                type="button"
                onClick={() => setNewDanger('low')}
                className={`py-1.5 rounded-lg border text-center cursor-pointer transition ${
                  newDanger === 'low' 
                    ? 'bg-emerald-950/40 text-emerald-400 border-emerald-800' 
                    : 'bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300'
                }`}
              >
                LOW
              </button>
              <button
                type="button"
                onClick={() => setNewDanger('medium')}
                className={`py-1.5 rounded-lg border text-center cursor-pointer transition ${
                  newDanger === 'medium' 
                    ? 'bg-yellow-950/40 text-yellow-400 border-yellow-800' 
                    : 'bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300'
                }`}
              >
                MED
              </button>
              <button
                type="button"
                onClick={() => setNewDanger('high')}
                className={`py-1.5 rounded-lg border text-center cursor-pointer transition ${
                  newDanger === 'high' 
                    ? 'bg-rose-950/45 text-rose-400 border-rose-800' 
                    : 'bg-slate-900 text-slate-500 border-slate-800 hover:text-slate-300'
                }`}
              >
                CRIT
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-[#155e75] hover:bg-[#0e7490] border border-cyan-700/50 text-white font-bold py-2.5 rounded-lg text-xs transition h-10 flex items-center justify-center gap-1 cursor-pointer"
          >
            Append Record
          </button>
        </form>

        <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-850 text-[10px] text-slate-400 font-mono flex items-center gap-1.5 h-12 leading-snug mt-4">
          <Info size={14} className="text-cyan-400 flex-shrink-0" />
          <span>Local threat filters are committed into encrypted partitions automatically.</span>
        </div>
      </div>

    </div>
  );
}
