import { DNSPacket, RuleWeights, ThreatFeedItem } from '../types';

// Lists of typical target domains for simulation
export const SIM_DOMAINS = [
  { domain: 'google.com', queryType: 'A' as const, safeIPs: ['142.250.190.46'], baselineTTL: 300 },
  { domain: 'hazara.edu.pk', queryType: 'A' as const, safeIPs: ['111.68.106.33'], baselineTTL: 3600 },
  { domain: 'github.com', queryType: 'A' as const, safeIPs: ['140.82.121.4'], baselineTTL: 60 },
  { domain: 'wikipedia.org', queryType: 'A' as const, safeIPs: ['198.35.26.96'], baselineTTL: 3600 },
  { domain: 'microsoft.com', queryType: 'A' as const, safeIPs: ['20.112.50.194', '20.81.111.85'], baselineTTL: 3600 },
  { domain: 'secure-bank-login.pk', queryType: 'A' as const, safeIPs: ['103.45.18.29'], baselineTTL: 1800 },
  { domain: 'netflix.com', queryType: 'A' as const, safeIPs: ['54.237.226.238', '3.220.104.41'], baselineTTL: 60 },
  { domain: 'amazon.com', queryType: 'A' as const, safeIPs: ['205.251.242.103'], baselineTTL: 60 }
];

export const ATTACK_DOMAINS = [
  { domain: 'trustedbank.pk.routing-node.xyz', queryType: 'A' as const, spoofedIPs: ['198.51.100.41'], realIPs: ['103.11.12.99'], baselineTTL: 3600 },
  { domain: 'hazara.edu.pk', queryType: 'A' as const, spoofedIPs: ['185.220.101.5'], realIPs: ['111.68.106.33'], baselineTTL: 3600 },
  { domain: 'payload-server.net', queryType: 'A' as const, spoofedIPs: ['203.0.113.88'], realIPs: ['12.18.19.20'], baselineTTL: 3600 },
  { domain: 'google.com', queryType: 'A' as const, spoofedIPs: ['91.109.12.33'], realIPs: ['142.250.190.46'], baselineTTL: 300 }
];

// Generate a random transaction ID (16-bit hex, 0000 - FFFF)
export function generateTxId(): string {
  return Math.floor(Math.random() * 65535).toString(16).toUpperCase().padStart(4, '0');
}

// Generate a random client IP from virtual local network
export function generateClientIP(): string {
  const localIPs = ['192.168.1.105', '192.168.1.112', '192.168.10.4', '10.0.0.42'];
  return localIPs[Math.floor(Math.random() * localIPs.length)];
}

// Calculate DNS packet size in bytes
export function estimatePacketSize(domain: string, answers: string[]): number {
  // Query part + Answer part + Headers
  return 12 + domain.length + 4 + (answers.length * 16);
}

// Score a packet based on active weights and network features
export function assessPacketRisk(
  packet: Partial<DNSPacket>,
  weights: RuleWeights,
  blacklist: string[]
): { score: number; notes: string[]; status: 'clean' | 'suspicious' | 'spoofed' } {
  let score = 0;
  const notes: string[] = [];

  // 1. Transaction ID mismatch
  if (packet.isSpoofedSimulation && Math.random() > 0.3) {
    // Under transaction ID spoofing simulations, we flag mismatch
    score += weights.txIdMismatch;
    notes.push('CRITICAL: Response DNS Transaction ID mismatch detected in raw packet stream.');
  }

  // 2. Blacklist / Threat Feed match
  if (packet.domain && blacklist.includes(packet.domain.toLowerCase())) {
    score += weights.blacklistMatch;
    notes.push(`THREAT INDEX: Domain [${packet.domain}] is flagged in loaded threat intelligence feeds.`);
  }

  // 3. TTL Anomaly
  if (packet.ttl !== undefined && packet.baselineTTL !== undefined) {
    if (packet.ttl < packet.baselineTTL * 0.1) {
      score += weights.ttlAnomaly;
      notes.push(`TTL ANOMALY: Highly dynamic TTL (${packet.ttl}s vs typical ${packet.baselineTTL}s), suspect rapid DNS switching.`);
    }
  }

  // 4. DNSSEC Validation
  if (!packet.dnssecValidated) {
    score += weights.dnssecMissing;
    notes.push('DNSSEC FAIL: Cryptographic chain validation failed or signatures are missing.');
  }

  // 5. Multiple Resolver Comparison
  if (packet.isSpoofedSimulation) {
    score += weights.ipGeoMismatch;
    notes.push('RESOLVER DISCREPANCY: Response IP differs significantly from Google, Cloudflare, and Quad9 DoH responses.');
  }

  // Bound score
  score = Math.min(Math.max(score, 0), 100);

  let status: 'clean' | 'suspicious' | 'spoofed' = 'clean';
  if (score >= 65) {
    status = 'spoofed';
  } else if (score >= 35) {
    status = 'suspicious';
  }

  return { score, notes, status };
}

// Generate a random clean packet
export function generateCleanPacket(blacklist: string[] = []): DNSPacket {
  const item = SIM_DOMAINS[Math.floor(Math.random() * SIM_DOMAINS.length)];
  const txId = generateTxId();
  const clientIp = generateClientIP();
  const ttl = item.baselineTTL;
  const isBlacklisted = blacklist.includes(item.domain.toLowerCase());

  // Simulate slight DNS lookup latency
  const latencyMs = Math.floor(Math.random() * 35) + 8; // 8-43ms

  // DNSSEC is typically valid for safe domains in our simulation
  const dnssecValidated = Math.random() > 0.1;

  const packet: Partial<DNSPacket> = {
    id: `pkt_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    transactionId: txId,
    timestamp: new Date().toLocaleTimeString(),
    domain: item.domain,
    queryType: item.queryType,
    sourceIP: clientIp,
    resolverIP: '192.168.1.1', // Default local gateway
    responseIPs: [...item.safeIPs],
    ttl: ttl,
    baselineTTL: item.baselineTTL,
    latencyMs,
    dnssecValidated,
    isSpoofedSimulation: false,
    sizeBytes: estimatePacketSize(item.domain, item.safeIPs),
  };

  const weights: RuleWeights = {
    txIdMismatch: 35,
    ttlAnomaly: 20,
    untrustedResolver: 15,
    dnssecMissing: 25,
    ipGeoMismatch: 35,
    blacklistMatch: 45
  };

  const verdict = assessPacketRisk(packet, weights, blacklist);

  return {
    ...packet,
    riskScore: verdict.score,
    status: verdict.status,
    notes: verdict.notes.length > 0 ? verdict.notes.join(' | ') : 'Packet verification passed. Matches trusted DNS state registries.',
    filtersInspected: ['PCAP Socket Capture', 'Header Parser', 'Blacklist Match', 'Cryptographic DNSSEC Validation', 'Multipath DoH Cross-Check']
  } as DNSPacket;
}

// Generate a spoofed/attack packet
export function generateSpoofedPacket(type: 'tx_hijack' | 'mismatch' | 'ttl_hijack' | 'blacklist_threat', blacklist: string[] = []): DNSPacket {
  const item = ATTACK_DOMAINS[Math.floor(Math.random() * ATTACK_DOMAINS.length)];
  const txId = generateTxId();
  const clientIp = generateClientIP();
  
  // Create variations in anomalies
  let recordTTL = item.baselineTTL;
  let dnssecValidated = false;
  let responseIPs = [...item.spoofedIPs];
  let customTxId = txId;
  let summary = 'Anomalous network conditions detected.';

  if (type === 'tx_hijack') {
    // Change query transaction ID in client representation to simulate packet injection mismatch
    customTxId = (parseInt(txId, 16) + 12).toString(16).toUpperCase().padStart(4, '0');
    dnssecValidated = false;
    summary = 'Forced DNS injection attack with mutated Transaction IDs.';
  } else if (type === 'ttl_hijack') {
    recordTTL = 2; // Dynamic 2-second malicious caching record
    dnssecValidated = false;
    summary = 'Rapid domain hopping attack with suspiciously low TTL values.';
  } else if (type === 'blacklist_threat') {
    // domain is in local threat list (or behaves as such)
    dnssecValidated = false;
    summary = 'Unauthorized resolution request pointing to blacklisted domain catalog.';
  } else {
    // Multi-resolver validation failure
    dnssecValidated = false;
    summary = 'IP spoofing discrepancy. Local gateway returned malware target IPs.';
  }

  // Latency is usually extremely low since the spoofed packets are racing to hit the client before the real resolver does (Fast Spoofing Race)
  const latencyMs = Math.floor(Math.random() * 4) + 1; // 1-5ms (extremely fast racing packet)

  const packet: Partial<DNSPacket> = {
    id: `pkt_atk_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
    transactionId: customTxId,
    timestamp: new Date().toLocaleTimeString(),
    domain: item.domain,
    queryType: item.queryType,
    sourceIP: clientIp,
    resolverIP: '192.168.1.1',
    responseIPs: responseIPs,
    ttl: recordTTL,
    baselineTTL: item.baselineTTL,
    latencyMs,
    dnssecValidated,
    isSpoofedSimulation: true,
    sizeBytes: estimatePacketSize(item.domain, responseIPs),
  };

  const weights: RuleWeights = {
    txIdMismatch: 35,
    ttlAnomaly: 20,
    untrustedResolver: 15,
    dnssecMissing: 25,
    ipGeoMismatch: 35,
    blacklistMatch: 45
  };

  const verdict = assessPacketRisk(packet, weights, blacklist);

  return {
    ...packet,
    riskScore: verdict.score,
    status: verdict.status,
    notes: verdict.notes.length > 0 ? verdict.notes.join(' | ') : summary,
    filtersInspected: ['PCAP Socket Capture', 'Header Parser', 'Blacklist Match', 'Cryptographic DNSSEC Validation', 'Multipath DoH Cross-Check']
  } as DNSPacket;
}
