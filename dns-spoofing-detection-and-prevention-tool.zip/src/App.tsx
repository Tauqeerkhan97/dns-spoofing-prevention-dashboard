/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { DNSPacket, RuleWeights, ThreatFeedItem, MitigationState, SystemLogEntry } from './types';
import LiveMonitor from './components/LiveMonitor';
import DefenseHub from './components/DefenseHub';
import FeedManager from './components/FeedManager';
import RuleScorer from './components/RuleScorer';
import SADViewer from './components/SADViewer';
import { 
  Shield, Activity, Settings, ListCollapse, BookOpen, 
  Users, AlertTriangle, ArrowRight, ShieldCheck, Mail, Globe, Sparkles
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Master Global States
  const [packets, setPackets] = useState<DNSPacket[]>([]);
  const [threatFeeds, setThreatFeeds] = useState<ThreatFeedItem[]>([
    { id: '1', domain: 'trustedbank.pk.routing-node.xyz', type: 'Phishing Mimic', addedDate: '06/06/2026', source: 'Quad9 Feed Sync', dangerLevel: 'high', active: true },
    { id: '2', domain: 'secure-gwy-portal.xyz', type: 'Unsigned Gateway', addedDate: '06/06/2026', source: 'Google Intel Feed', dangerLevel: 'medium', active: true },
    { id: '3', domain: 'unauthorized-hazara-auth.net', type: 'Credential Harvesting', addedDate: '05/06/2026', source: 'User Manual Entry', dangerLevel: 'high', active: true },
    { id: '4', domain: 'payload-server.net', type: 'Command & Control', addedDate: '04/06/2026', source: 'Cloudflare Feed Sync', dangerLevel: 'high', active: true }
  ]);

  const [ruleWeights, setRuleWeights] = useState<RuleWeights>({
    txIdMismatch: 35,
    ttlAnomaly: 20,
    untrustedResolver: 15,
    dnssecMissing: 25,
    ipGeoMismatch: 35,
    blacklistMatch: 45
  });

  const [mitigationState, setMitigationState] = useState<MitigationState>({
    dnsCacheFlushed: false,
    dohForced: false,
    firewallRulesCount: 0,
    hostsFileSecure: false
  });

  const [systemLogs, setSystemLogs] = useState<SystemLogEntry[]>([
    { id: 'log_1', timestamp: '09:09:44', component: 'Daemon', level: 'success', message: 'DNSGuard core daemon process started successfully. Loaded system sockets.' },
    { id: 'log_2', timestamp: '09:09:44', component: 'Updater', level: 'info', message: 'Synchronized local cryptographic DNSSEC anchors from international registrar roots.' },
    { id: 'log_3', timestamp: '09:09:45', component: 'GUI', level: 'success', message: 'PyQt6 GUI dashboard opened. Attached named pipe listener successfully.' },
    { id: 'log_4', timestamp: '09:09:45', component: 'Daemon', level: 'info', message: 'Ready to receive packet intercepts on active interfaces.' }
  ]);

  // Handle addition of new captured packet
  const handleAddPacket = (pkt: DNSPacket) => {
    setPackets((prev) => {
      // Limit rolling packet buffer to prevent memory exhaustion
      const b = [pkt, ...prev];
      if (b.length > 80) b.pop();
      return b;
    });

    // Check if packet triggers auto firewalls when spoofed
    if (pkt.status === 'spoofed') {
      // Automated mitigate trigger simulation
      setMitigationState((prev) => {
        // Only increment if rules isn't excessively huge
        const rules = prev.firewallRulesCount < 10 ? prev.firewallRulesCount + 1 : prev.firewallRulesCount;
        return {
          ...prev,
          dnsCacheFlushed: true, // Trigger automatically on spoof detections
          firewallRulesCount: rules
        };
      });

      // Avoid double logging alerts by putting the logic inside App or components selectively
    }
  };

  const handleClearPackets = () => {
    setPackets([]);
    handleAddSystemLog('GUI', 'info', 'Cleared active packet capture logging lists.');
  };

  // Log handler
  const handleAddSystemLog = (
    comp: 'Daemon' | 'GUI' | 'Updater' | 'Mitigator',
    lvl: 'info' | 'warning' | 'error' | 'success',
    msg: string
  ) => {
    setSystemLogs((prev) => {
      const b = [
        {
          id: `log_${Date.now()}_${Math.floor(Math.random()*100)}`,
          timestamp: new Date().toLocaleTimeString(),
          component: comp,
          level: lvl,
          message: msg
        },
        ...prev
      ];
      if (b.length > 100) b.pop();
      return b;
    });
  };

  const handleClearLogs = () => {
    setSystemLogs([]);
  };

  // Sync Threat Feeds callback
  const handleSyncFeeds = () => {
    // Add multiple public target threat indicators
    const syncedItems: ThreatFeedItem[] = [
      { id: `syn_${Date.now()}_1`, domain: 'eviltracker-host.pk', type: 'Spam Server', addedDate: '06/06/2026', source: 'Quad9 Feed Sync', dangerLevel: 'high', active: true },
      { id: `syn_${Date.now()}_2`, domain: 'hijack-resolve.org', type: 'Phishing Mimic', addedDate: '06/06/2026', source: 'Google Intel Feed', dangerLevel: 'medium', active: true },
      { id: `syn_${Date.now()}_3`, domain: 'rogue-anchor-dns.net', type: 'Unsigned Gateway', addedDate: '06/06/2026', source: 'Cloudflare Feed Sync', dangerLevel: 'high', active: true }
    ];

    setThreatFeeds((prev) => {
      // Filter out duplicate entries
      const cleanPrev = prev.filter(item => !syncedItems.some(item2 => item2.domain === item.domain));
      return [...cleanPrev, ...syncedItems];
    });
  };

  // Get active blacklist strings
  const blacklistDomains = threatFeeds.map(f => f.domain.toLowerCase());

  return (
    <div className="min-h-screen bg-slate-900 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-950 via-slate-900 to-slate-950 text-slate-100 font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Institution Custom Banners */}
      <div className="bg-[#155e75] text-[10.5px] font-mono text-cyan-100 tracking-wider py-2 border-b border-cyan-700/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center text-center sm:text-left gap-1">
          <span>DEPARTMENT OF TELECOMMUNICATION, HAZARA UNIVERSITY, MANSEHRA</span>
          <span className="font-semibold text-white">ASSIGNMENT - 03 | SOFTWARE ARCHITECTURE CERTIFY</span>
        </div>
      </div>

      {/* Primary Container Wrap */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Top Branding Section */}
        <header className="mb-6 flex flex-col md:flex-row justify-between items-start md:items-center bg-slate-950/40 p-5 rounded-2xl border border-slate-800/80 gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-cyan-400 uppercase tracking-widest">
              <Shield size={14} className="text-[#10b981]" />
              <span>CYS122: Systems Software Engineering</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white mt-1 flex items-center gap-1.5 flex-wrap">
              <span>DNS Spoofing Detection & Prevention</span>
              <span className="bg-cyan-950 border border-cyan-800/60 text-cyan-400 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                DNSGuard
              </span>
            </h1>
          </div>
          
          {/* Authors List Pill */}
          <div className="flex bg-slate-900/60 p-2.5 rounded-xl border border-slate-850 gap-4 text-xs font-mono shrink-0">
            <div>
              <span className="text-slate-500 block text-[9px] uppercase tracking-wider font-semibold">Submitted By Team:</span>
              <div className="flex gap-2 text-slate-300 mt-1 flex-wrap">
                <span className="hover:text-cyan-400 transition" title="Roll: 3054-251013">Naveed A.</span>
                <span className="text-slate-700">•</span>
                <span className="hover:text-cyan-400 transition" title="Roll: 3054-251046">Nazar S.</span>
                <span className="text-slate-700">•</span>
                <span className="hover:text-cyan-400 transition" title="Roll: 3054-251028">Abdual A.</span>
              </div>
            </div>
            <div className="border-l border-slate-800 pl-3">
              <span className="text-slate-500 block text-[9px] uppercase tracking-wider font-semibold">Tutor Evaluation:</span>
              <span className="text-slate-300 font-bold block mt-1">Dr. Waqar Ishaq</span>
            </div>
          </div>
        </header>

        {/* Tab Selection Row */}
        <div className="flex flex-wrap bg-slate-950 p-1.5 rounded-xl border border-slate-850/90 mb-6 gap-1 gap-y-2">
          
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-4 py-2.5 rounded-lg text-xs font-bold uppercase transition duration-150 flex items-center gap-2 cursor-pointer ${
              activeTab === 'dashboard'
                ? 'bg-cyan-950 text-cyan-400 border border-cyan-800/60 font-semibold shadow'
                : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
            }`}
          >
            <Activity size={13} />
            <span>Incident Dashboard</span>
          </button>

          <button
            onClick={() => setActiveTab('defense')}
            className={`px-4 py-2.5 rounded-lg text-xs font-bold uppercase transition duration-150 flex items-center gap-2 cursor-pointer ${
              activeTab === 'defense'
                ? 'bg-cyan-950 text-cyan-400 border border-cyan-800/60 font-semibold shadow'
                : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
            }`}
          >
            <ShieldCheck size={13} />
            <span>Mitigation Hub</span>
          </button>

          <button
            onClick={() => setActiveTab('feeds')}
            className={`px-4 py-2.5 rounded-lg text-xs font-bold uppercase transition duration-150 flex items-center gap-2 cursor-pointer ${
              activeTab === 'feeds'
                ? 'bg-cyan-950 text-cyan-400 border border-cyan-800/60 font-semibold shadow'
                : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
            }`}
          >
            <ListCollapse size={13} />
            <span>Threat Intel Feeds</span>
          </button>

          <button
            onClick={() => setActiveTab('rules')}
            className={`px-4 py-2.5 rounded-lg text-xs font-bold uppercase transition duration-150 flex items-center gap-2 cursor-pointer ${
              activeTab === 'rules'
                ? 'bg-cyan-950 text-cyan-400 border border-cyan-800/60 font-semibold shadow'
                : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
            }`}
          >
            <Settings size={13} />
            <span>Heuristic Scorers</span>
          </button>

          <button
            onClick={() => setActiveTab('sad-doc')}
            className={`px-4 py-2.5 rounded-lg text-xs font-bold uppercase transition duration-150 flex items-center gap-2 cursor-pointer md:ml-auto ${
              activeTab === 'sad-doc'
                ? 'bg-[#155e75] text-white border border-cyan-600/60 shadow'
                : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
            }`}
          >
            <BookOpen size={13} />
            <span>Assignment SAD Report</span>
          </button>

        </div>

        {/* View Layout Display Router */}
        <div className="transition duration-150">
          {activeTab === 'dashboard' && (
            <LiveMonitor
              packets={packets}
              onAddPacket={handleAddPacket}
              onClearPackets={handleClearPackets}
              weights={ruleWeights}
              blacklist={blacklistDomains}
              onAddSystemLog={handleAddSystemLog}
              mitigationState={mitigationState}
            />
          )}

          {activeTab === 'defense' && (
            <DefenseHub
              packets={packets}
              mitigationState={mitigationState}
              onUpdateMitigation={(key, val) => setMitigationState(prev => ({ ...prev, [key]: val }))}
              systemLogs={systemLogs}
              onAddSystemLog={handleAddSystemLog}
              onClearLogs={handleClearLogs}
            />
          )}

          {activeTab === 'feeds' && (
            <FeedManager
              threatFeeds={threatFeeds}
              onAddFeedItem={(item) => setThreatFeeds(prev => [item, ...prev])}
              onRemoveFeedItem={(id) => setThreatFeeds(prev => prev.filter(f => f.id !== id))}
              onSyncFeeds={handleSyncFeeds}
              onAddSystemLog={handleAddSystemLog}
            />
          )}

          {activeTab === 'rules' && (
            <RuleScorer
              weights={ruleWeights}
              onUpdateWeight={(key, val) => setRuleWeights(prev => ({ ...prev, [key]: val }))}
              onResetWeights={() => setRuleWeights({
                txIdMismatch: 35,
                ttlAnomaly: 20,
                untrustedResolver: 15,
                dnssecMissing: 25,
                ipGeoMismatch: 35,
                blacklistMatch: 45
              })}
              onAddSystemLog={handleAddSystemLog}
            />
          )}

          {activeTab === 'sad-doc' && (
            <SADViewer />
          )}
        </div>

      </div>

      {/* Footer Content */}
      <footer className="mt-12 border-t border-slate-800/80 bg-slate-950 py-8 text-center text-xs text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p>© 2026 Dept. of Telecommunication | Hazara University, Mansehra, Pakistan.</p>
          <p className="text-[11px] text-slate-650">
            Course Title: Introduction to Software Engineering (CYS122) | Instructor: Dr. Waqar Ishaq
          </p>
          <div className="flex justify-center gap-6 pt-3 text-[10px] text-slate-600">
            <span>Assignment Group: Naveed Ahmad • Nazar Sha • Abdual Aziz</span>
            <span>•</span>
            <span>Graded Submission Platform Ready</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
