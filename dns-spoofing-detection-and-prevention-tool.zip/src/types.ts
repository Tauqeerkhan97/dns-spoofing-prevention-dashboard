export interface DNSPacket {
  id: string;
  transactionId: string;
  timestamp: string;
  domain: string;
  queryType: 'A' | 'AAAA' | 'MX' | 'TXT' | 'CNAME';
  sourceIP: string;
  resolverIP: string;
  responseIPs: string[];
  ttl: number;
  baselineTTL?: number;
  latencyMs: number;
  dnssecValidated: boolean;
  dnssecDetails?: string;
  riskScore: number; // 0 to 100
  status: 'clean' | 'suspicious' | 'spoofed';
  isSpoofedSimulation?: boolean;
  filtersInspected: string[];
  notes: string;
  sizeBytes: number;
}

export interface RuleWeights {
  txIdMismatch: number;
  ttlAnomaly: number;
  untrustedResolver: number;
  dnssecMissing: number;
  ipGeoMismatch: number;
  blacklistMatch: number;
}

export interface ThreatFeedItem {
  id: string;
  domain: string;
  type: string;
  addedDate: string;
  source: string;
  dangerLevel: 'low' | 'medium' | 'high';
  active: boolean;
}

export interface MitigationState {
  dnsCacheFlushed: boolean;
  dohForced: boolean;
  firewallRulesCount: number;
  hostsFileSecure: boolean;
}

export interface SystemLogEntry {
  id: string;
  timestamp: string;
  component: 'Daemon' | 'GUI' | 'Updater' | 'Mitigator';
  level: 'info' | 'warning' | 'error' | 'success';
  message: string;
}

export interface FilterStage {
  id: string;
  name: string;
  role: string;
  icon: string;
  description: string;
  status: 'idle' | 'processing' | 'passed' | 'fired';
  count: number;
}
