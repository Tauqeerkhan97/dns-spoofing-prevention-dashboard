export interface SADSection {
  id: string;
  title: string;
  subtitle?: string;
  content: string[];
  bullets?: string[];
  subsections?: { subtitle: string; bullets?: string[]; body?: string }[];
}

export const ACADEMIC_INFO = {
  institution: "Department of Telecommunication, Hazara University, Mansehra",
  assignment: "Assignment - 03: System Architecture",
  course: "Introduction to Software Engineering",
  code: "CYS122",
  topic: "DNS Spoofing Detection and Prevention Tool",
  docTitle: "Software Architecture Document",
  instructor: "Dr. Waqar Ishaq",
  submissionDate: "Monday / 15-June-2026",
  authors: [
    { name: "Naveed Ahmad", rollNo: "3054-251013" },
    { name: "Nazar Sha", rollNo: "3054-251046" },
    { name: "Abdual Aziz", rollNo: "3054-251028" }
  ]
};

export const SAD_SECTIONS: SADSection[] = [
  {
    id: "introduction",
    title: "1. Introduction",
    content: [
      "This Software Architecture Document (SAD) describes the architecture of the DNS Spoofing Detection and Prevention Tool. It follows the 4+1 View Model (Logical, Process, Development, Physical, and Scenarios). The architecture refines the design from Assignment 02 and provides the technical contract used by the implementation team."
    ],
    subsections: [
      {
        subtitle: "1.1 Purpose",
        body: "To present the architectural decisions, components, connectors, and deployment topology required to build, deploy, and operate the system. The document also justifies the chosen architectural style and analyses the trade-offs."
      },
      {
        subtitle: "1.2 Architectural Drivers",
        bullets: [
          "Real-time threat detection: the system must analyse DNS packets at line rate.",
          "Cross-platform: single code base targeting Windows, Linux, macOS.",
          "Privileged access: needs raw socket access yet must remain safe to run.",
          "Extensibility: new detection rules and threat feeds must plug in without rewriting core.",
          "Offline-capable: must function even when only the trusted resolver is reachable."
        ]
      }
    ]
  },
  {
    id: "style",
    title: "2. Architectural Style",
    content: [
      "The chosen style is a Layered + Pipe-and-Filter hybrid wrapped in a Service-Oriented background daemon, with a Model-View-Controller (MVC) presentation layer.",
      "DNS packets naturally flow through a series of independent processing stages (capture -> parse -> validate -> score -> mitigate -> log). A pipe-and-filter pipeline maps onto this flow perfectly and allows individual filters to be swapped or run in parallel.",
      "The service-oriented daemon decouples the long-running capture/detection engine from the user-facing GUI; either can be restarted independently."
    ],
    subsections: [
      {
        subtitle: "Trade-offs and Mitigation Matrix",
        body: "Every architectural style carries costs. We actively mitigate these through technical strategies:"
      }
    ]
  },
  {
    id: "views",
    title: "3. 4+1 Architectural Views",
    content: [
      "The system architecture is detailed using the standard 4+1 View Model to capture different stakeholders' perspectives."
    ],
    subsections: [
      {
        subtitle: "3.1 Logical View",
        body: "Describes the major functional packages and their static relationships. Organized cleanly as: Presentation Layer (Dashboard, Alerts, Reports), Application Layer (Controller, Alert IP Bus), Domain Layer (Detection, Mitigation, Scoring Rules), and Infrastructure Layer (Capture Socket, OS Hooks, sqlite persistence)."
      },
      {
        subtitle: "3.2 Process View",
        body: "Illustrates the three long-running processes that cooperate concurrently at runtime: the high-privilege dnsguard-daemon (captures and inspects traffic), the user-space dnsguard-gui (PyQt front-end sharing IPC), and the low-priority dnsguard-updater (pulls signed feed lists and anchor updates)."
      },
      {
        subtitle: "3.3 Development View (Package Structure)",
        body: "Outlines physical code nesting. Structured into: 'app' (controllers), 'presentation' (Qt / user interface widgets), 'domain' (detection heuristics and scorers), 'infrastructure' (raw pcap and SQLCipher repositories), and 'service/watchdog'."
      },
      {
        subtitle: "3.4 Physical (Deployment) View",
        body: "Visualizes hardware topology. The background service daemon and the database run on the end-user workstation, dispatching authenticated DNS-over-HTTPS (DoH) validations out to Cloudflare (1.1.1.1), Google (8.8.8.8), and Quad9 (9.9.9.9) resolver networks."
      },
      {
        subtitle: "3.5 Scenarios (+1)",
        bullets: [
          "S-01: User starts monitoring -> daemon begins packet capture -> GUI updates dashboard instantly.",
          "S-02: Spoofed answer detected -> mitigation actions run in sequence -> user receives active OS alerts.",
          "S-03: Threatened domain feeds update -> background updater pulls files -> daemon hot-reloads local engine.",
          "S-04: GUI unexpectedly crashes -> background daemon stays alive; watchdogs trigger safe GUI reconnection.",
          "S-05: Offline Mode -> external anchors are unreached -> pipeline relies on offline cryptographic DNSSEC."
        ]
      }
    ]
  },
  {
    id: "components",
    title: "4. Component & Connector View",
    content: [
      "Detailed connector logic: raw network interfaces write to buffered Scapy sockets. Data passes sequentially through independent filters via thread-safe bounded task queues. If anomalous headers trigger high risks, the AlertDispatcher triggers parallel mitigation actions.",
      "Supported Connectors: Fast bounded queues prevent memory buildup. Synchronous connections securely persist alerts and threat statuses into SQLCipher repos. Bidirectional local IPC Named Pipes deliver immediate push alerts to the GUI controller."
    ]
  },
  {
    id: "tech_stack",
    title: "5. Technology Stack",
    content: [
      "The chosen software components provide mature, reliable cross-platform execution:"
    ],
    subsections: [
      {
        subtitle: "Core Components",
        bullets: [
          "Development Environment: Python 3.11 (mature cross-platform sockets & typing support).",
          "Packet Capture: Scapy + Npcap for raw socket listening on Windows, libpcap on Linux/macOS.",
          "Verification Layer: dnspython + getdns for offline DNSSEC validation.",
          "Validation Network: Trusted DoH (RFC 8484) running via requests to bypass local caches.",
          "GUI Engine: PyQt6 + QtCharts supporting native threading, widgets, and styles.",
          "Local Storage: SQLCipher + SQLite rendering an encrypted, zero-administration relational store."
        ]
      }
    ]
  },
  {
    id: "quality",
    title: "6. Architecture Quality Attributes",
    content: [
      "Key non-functional specifications driving architectural validation:"
    ],
    subsections: [
      {
        subtitle: "6.1 Performance & Throughput",
        body: "The parsing and evaluation pipeline operates with bounded buffers (max 10,000 packets) preventing RAM bloating. Thread-pool executors match physical core counts, maintaining latencies below 50ms at peak lines."
      },
      {
        subtitle: "6.2 Reliability",
        body: "Uses systemd monitors and Windows Service auto-recovery. SQLite is locked in Write-Ahead-Logging (WAL) mode supporting power-loss consistency. Health beats run every 5s between daemon and front-end."
      },
      {
        subtitle: "6.3 Security Hardening",
        body: "Enforces 256-bit AES database encryption at rest. Forces encrypted DoH queries to resist local tamper attempts. Capture processes bind immediately to privileged raw sockets and immediately drop OS privileges to avoid elevation risk."
      }
    ]
  },
  {
    id: "adr",
    title: "7. Key Architectural Decisions (ADR Summary)",
    content: [
      "Five formal Architectural Decision Records (ADRs) outline system constraints and alternatives rejected:"
    ],
    bullets: [
      "ADR-1: Use Python (Scapy/PyQt6) over C++ -> Rapid time-to-market and robust native network libraries, despite minimal CPU overhead.",
      "ADR-2: Decoupled service daemon & GUI processes -> Continuous background protection even if the user interface locks up or crashes.",
      "ADR-3: SQLite with SQLCipher -> Lightweight, encrypted, embedded layout vs operational overhead of managing local Postgres servers.",
      "ADR-4: DNS-Over-HTTPS for Trusted Lookups -> Guarantees a clean, encrypted lookup pathway bypassing corrupted intermediate routers.",
      "ADR-5: Pipe-and-Filter Detection Chain -> Highly pluggable design allowing runtime custom rule injections without altering baseline parsers."
    ]
  }
];

export const ADR_DATABASE = [
  {
    id: "ADR-1",
    decision: "Use Python instead of C++",
    reason: "Faster cross-platform development, rich network capture extensions.",
    alternative: "C++ (Rejected: long compiling times, slower to scale and test)"
  },
  {
    id: "ADR-2",
    decision: "Split daemon and GUI processes",
    reason: "Continuous background packet capture and active defense even if PyQt front-end crashes.",
    alternative: "Single process (Rejected: GUI crash stops network guarding)"
  },
  {
    id: "ADR-3",
    decision: "SQLCipher with SQLite",
    reason: "Embeddable, robust, zero server dependencies, fully encrypted with AES-256.",
    alternative: "PostgreSQL database (Rejected: requires admin configurations and background local setup)"
  },
  {
    id: "ADR-4",
    decision: "DoH (DNS-over-HTTPS) Lookup",
    reason: "Circumvents compromised gateway routers to establish baseline truth.",
    alternative: "Standard UDP queries (Rejected: exposed to identical MITM packet injection)"
  },
  {
    id: "ADR-5",
    decision: "Pipe-and-Filter Design Pattern",
    reason: "Composable filters can run concurrently over incoming packets.",
    alternative: "Monolithic check loop (Rejected: hard to extend with custom feed and logic)"
  }
];
